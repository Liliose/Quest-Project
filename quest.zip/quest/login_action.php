<?php session_start();
include "class/connection.php";
       $username = $_POST['email'];
        $password = $_POST['password'];
        //$usr == $username && $psw == $password

function define_access($access){

switch ($access) {
  case "1":
    $return ="paroise";
    break;
  case "2":
    $return ="admin";
    break;
  case "3":
    $return ="installer";
    break;
      case "4":
    $return ="accountant";
    break;
      case "5":
    $return ="agent";
    break;
   
  default:
    $return ="unknown";
}
return $return;
}



     
   $sql= "SELECT * FROM users where email='$username' and password='$password'";
    $data=$conn->query($sql);
    if($data->num_rows > 0){
        $row=$data->fetch_assoc();
        $username=$row['last_name'];
        $last_name=$row['last_name'];
        $_SESSION['username']=$row['first_name'].' '.$row['last_name'];   
        $_SESSION['email']=$row['email'];  
        $_SESSION['user_level_id']=$row['user_level_id'];
        $_SESSION['login']=true;
        $access=$row['user_level_id'];

        $_SESSION['access']=define_access($access);
        $_SESSION['user_id']=$row['user_id'];
        header("location:index.php");

        }
        else {


  $_SESSION['login']=false;
  header("location:login.php");
        }





   
?>