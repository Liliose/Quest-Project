<?php

class dbConnection{
protected $db_conn;
public $db_host = "localhost";
public $db_user = "root";
public $db_pass = "";
public $db_name = "energy";

function connect(){

    $this->db_conn = new mysqli("localhost","root","","energy");
    return $this->db_conn;
}
}
//userActions
class userActions{

    public $link;      
    public $db_connection;  
    function __construct(){
        $db_connection = new dbConnection();
        $this->link = $db_connection->connect();   
        return $this->link;
    }

function get_user_details($user_id){

$this->query ="SELECT * FROM users where user_id='$user_id'";

     return $data=$this->link->query($this->query)->fetch_assoc();
}

//registerUsers
   function registerUsers($first_name, $last_name, $national_id, $phone, $email, $password, $user_level_id, $paroise_id, $status,$date_added){

$this->query ="INSERT INTO `users` (`user_id`, `first_name`, `last_name`, `national_id`, `phone`, `email`, `password`, `user_level_id`, `paroise_id`, `status`, `date_added`) VALUES
       ('', '$first_name', '$last_name', '$national_id', '$phone', '$email', '$password','$user_level_id','$paroise_id', '$status', '$date_added')";

     return $this->link->query($this->query);

    }


//registerprovince
  function registerprovince($province_name,$date_added){

$this->query="INSERT INTO `province` (`province_id`, `province_name`, `p_recorded_date`) VALUES ('', '$province_name', '$date_added')";

    return $this->link->query($this->query);

    }



//registerdistrict
  function registerdistrict($district_name,$province_id,$date_added){

$this->query="INSERT INTO `districts` (`district_id`, `district_name`, `province_id`, `d_recorded_date`) VALUES
('', '$district_name', '$province_id', '$date_added')";

    return $this->link->query($this->query);

    }


  function register_sucrisale($paroise_id,$sucrisale_name,$date_added){

$this->query="INSERT INTO `sucrisale` (`id`, `sucrisale_name`, `paroise_id`, `d_recorded_date`) VALUES
('', '$sucrisale_name', '$paroise_id', '$date_added')";

    return $this->link->query($this->query);

    }


  function register_umuryango($sucrisale_id,$umuryango_name,$date_added){

$this->query="INSERT INTO `imiryango` (`id`, `umuryango_name`, `sucrisale_id`, `d_recorded_date`) VALUES
('', '$umuryango_name', '$sucrisale_id', '$date_added')";

    return $this->link->query($this->query);

    }


//registerpayment_mode
  function registerpayment_mode($method_name){

$this->query="INSERT INTO `payment_mode` (`payment_id`, `method_name`) VALUES
('', '$method_name')";

    return $this->link->query($this->query);

    }

//registerpermissions
  function registerpermissions($module_id, $admin, $agent, $installer, $paroise, $accountant){

$this->query="INSERT INTO `permissions` (`perm_id`, `module_id`, `admin`, `agent`, `installer`, `paroise`, `accountant`) VALUES ('', '$module_id', '$admin', '$agent', '$installer', '$paroise', '$accountant')";

    return $this->link->query($this->query);

    }

//registerpermission_levels
  function registerpermission_levels($level_name, $date_added){

$this->query="INSERT INTO `permission_levels` (`level_id`, `level_name`, `lev_recorded_date`) VALUES ('', '$level_name', '$date_added')";

return $this->link->query($this->query);

    }

//registersystem_modules
function registersystem_modules($system_module, $module_status, $date_added){

$this->query="INSERT INTO `system_modules` (`module_id`, `module_name`, `module_status`, `m_recorded_date`) VALUES ('','$system_module','$module_status','$date_added')";

return $this->link->query($this->query);

    }
//save kit installer
function register_assign_installer($national_id, $serial_number, $date_added){

$this->query="INSERT INTO `kit_installer_assigned` (`kit_installer_serial_number`, `assigned_installer_id`, `assigned_date`, `installer_kit_status`) VALUES ('$serial_number', '$national_id', '$date_added', '1')";

return $this->link->query($this->query);

    }
function register_payment($payment_reference,$national_id, $payment_method, $months, $monthly_installement, $from_date, $to_date, $means_of_payment, $sacco_branch, $account_name, $account_number, $status, $user_id, $date_added)
{

$this->query="INSERT INTO `payments` (`id`, `national_id`, `payment_method`, `months`, `monthly_installement`, `from_date`, `to_date`, `means_of_payment`, `sacco_branch`, `account_name`, `account_number`, `status`, `user_id`, `date_added`) VALUES ('$payment_reference', '$national_id', '$payment_method', '$months', '$monthly_installement', '$from_date', '$to_date', '$means_of_payment', '$sacco_branch', '$account_name', '$account_number', '$status', '$user_id', '$date_added')";

return $this->link->query($this->query);

    }



//registerparoise
 function registerparoise($paroise_name,$district_id,$date_added){

$this->query ="INSERT INTO `paroise` (`paroise_id`, `paroise_name`, `district_id`, `pa_recorded_date`) VALUES ('', '$paroise_name', '$district_id', '$date_added')";

 return $this->link->query($this->query);

    }
//registercustomer
 function registercustomer($cust_national_id, $cust_fname, $cust_mname, $cust_lname, $cust_phone_number, $cust_email, $cust_district, $cust_sector, $cust_cell, $cust_village, $cust_gender, $cust_ubudehe,$paroisse_id,$umuryango_id,$suscrisale_id,$isibo,$full_address){

$this->query ="INSERT INTO `customers` (`cust_national_id`, `cust_fname`, `cust_mname`, `cust_lname`, `cust_phone_number`, `cust_email`, `cust_district`, `cust_sector`, `cust_cell`, `cust_village`, `cust_gender`, `cust_ubudehe`,`paroisse_id`,`umuryango_id`,`suscrisale_id`,`isibo`,`full_address`) VALUES ('$cust_national_id', '$cust_fname', '$cust_mname', '$cust_lname', '$cust_phone_number', '$cust_email', '$cust_district', '$cust_sector', '$cust_cell', '$cust_village', '$cust_gender', '$cust_ubudehe','$paroisse_id','$umuryango_id','$suscrisale_id','$isibo','$full_address')";
return $this->link->query($this->query);
}

//registercustomer_details
 function registercustomer_details($cust_d_national_id, $cust_d_recorded_date, $user_id, $paroise_id, $pre_registration_date, $cust_confirmation_date, $cust_d_status){

$this->query ="INSERT INTO `customer_details` (`cust_d_national_id`, `cust_d_recorded_date`, `user_id`, `paroise_id`, `pre_registration_date`, `cust_confirmation_date`, `cust_d_status`) VALUES ($cust_d_national_id, '$cust_d_recorded_date', '$user_id', '$paroise_id', '$pre_registration_date', '$cust_confirmation_date', '$cust_d_status')";
  return $this->link->query($this->query);

    }
//registercomplete_installation
function registercomplete_installation($cust_installed_national_id, $installer_id, $kit_installed_serial_number, $installation_date, $image_a, $image_b, $image_c){
$this->query ="INSERT INTO `complete_installation` (`installation_id`, `cust_installed_national_id`, `installer_id`, `kit_installed_serial_number`, `installation_date`, `image_a`, `image_b`, `image_c`, `installation_recorded_date`, `installation_status`, `installation_status_changed_date`, `installation_status_changed_by`) 

VALUES ('', '$cust_installed_national_id', '$installer_id', '$kit_installed_serial_number', '$installation_date', '$image_a', '$image_b', '$image_c', '0', '0', '0', '0')";
return $this->link->query($this->query);

    }

//registercomplete_installation_payment
 function registercomplete_installation_payment($complete_installation_payment_id, $installation_id, $payment_id, $price_to_endcustomer, $number_of_installments, $installment_per_month, $payment_from, $payment_to, $install_payment_recorded_date, $install_payment_recorded_by){

$this->query ="INSERT INTO `complete_installation_payment` (`complete_installation_payment_id`, `installation_id`, `payment_id`, `price_to_endcustomer`, `number_of_installments`, `installment_per_month`, `payment_from`, `payment_to`, `install_payment_recorded_date`, `install_payment_recorded_by`) VALUES ('', '$installation_id', '$payment_id', '$price_to_endcustomer', '$number_of_installments', '$installment_per_month', '$payment_from', '$payment_to','$install_payment_recorded_date', '$user_id')";
  return $this->link->query($this->query);

    }

    //registercustomer_status_history

 function registercustomer_status_history($cust_d_national_id, $cust_d_recorded_date, $user_id, $paroise_id, $pre_registration_date, $cust_confirmation_date, $cust_d_status){

$this->query ="INSERT INTO `customer_status_history` (`cust_status_id`, `national_id`, `user_id`, `status_from`, `status_to`, `status_change_date`) VALUES ('', '$national_id', '$user_id', 'status_from', 'status_to', '$status_change_date')";
  return $this->link->query($this->query);

    }
function grant_permission_module_id($user_id,$module_id){
$this->querys="SELECT level_name from users natural join permission_levels where user_id='$user_id' and permission_levels.level_id=users.user_level_id";
$this->data=$this->link->query($this->querys);
$fields=$this->data->fetch_assoc();
$userfieldname=$fields['level_name'];
$this->query ="SELECT * FROM permissions where module_id='$module_id' and $userfieldname='1'";
      $data=$this->link->query($this->query)->fetch_assoc();
      return $user_perm=$data[$userfieldname];

}
 function register_main_stock($kit_serial_number, $kit_image, $kit_category, $kit_description, $kit_recorded_date, $kit_status){

$this->query ="INSERT INTO `main_kits_stock` (`kit_serial_number`, `kit_image`, `kit_category`, `kit_description`, `kit_recorded_date`, `kit_status`, `is_paroise_assigned`, `is_installer_assigned`, `is_used`, `user_id`) VALUES ('$kit_serial_number', 'kit_image', '$kit_category', '$kit_description', '$kit_recorded_date', '1', '0', '0', '0', '0')";
  return $this->link->query($this->query);

    }


function return_customer_details($national_id){

$this->querys="SELECT * from customers where national_id='$national_id'";
$this->data=$this->link->query($this->querys);
$fields=$this->data->fetch_assoc();
return $fields;
}

function return_kit_details($serial_number){

$this->querys="SELECT * from main_kits_stock where kit_serial_number='$serial_number'";
$this->data=$this->link->query($this->querys);
$fields=$this->data->fetch_assoc();
return $fields;
}

function update_single($status,$table,$field_name,$id,$provided_id){
$this->query="UPDATE $table set $field_name='$status' where $id='$provided_id'";
return $this->link->query($this->query);
}
function update_multiple($status,$table,$field_name,$id,$provided_id){
$this->query="UPDATE $table set $field_name='$status' where $id='$provided_id'";
return $this->link->query($this->query);
}

//lets count total payments made

function count($table,$field){

$this->querys="SELECT count($field) as row from $table ";
return $this->data=$this->link->query($this->querys);
 
}


function view_users(){

$this->querys="SELECT * from users ";
return $this->data=$this->link->query($this->querys);
 
}
function view_users_where($id){

$this->querys="SELECT * from users where user_id='$id'";
return $this->data=$this->link->query($this->querys);
 
}


function view_paroise(){

$this->querys="SELECT * from paroise ";
return $this->data=$this->link->query($this->querys);
 
}
function view_permissions(){

$this->querys="SELECT * from permissions ";
return $this->data=$this->link->query($this->querys);
 
}

function view_customers(){

$this->querys="SELECT * from customers ";
return $this->data=$this->link->query($this->querys);
 
}
function view_system_modules(){

$this->querys="SELECT * from system_modules ";
return $this->data=$this->link->query($this->querys);
}

function view_main_kits_stock(){

$this->querys="SELECT * from main_kits_stock where kit_status='1' and is_used='0'";
return $this->data=$this->link->query($this->querys);
}

function view_customer_detail(){

$this->querys="SELECT * from customers";
return $this->data=$this->link->query($this->querys);
}

function view_districts(){

$this->querys="SELECT * from districts ";
return $this->data=$this->link->query($this->querys);
 
}

function view_customer_details(){

$this->querys="SELECT * from customer_details ";
return $this->data=$this->link->query($this->querys);
 
}
function view_payment_mode(){

$this->querys="SELECT * from payment_mode ";
return $this->data=$this->link->query($this->querys);
 
}
function view_kit_installer_assigned(){

$this->querys="SELECT * from kit_installer_assigned ";
return $this->data=$this->link->query($this->querys);

}
function view_kits_paroise_assigned(){
$this->querys="SELECT * from kits_paroise_assigned ";
return $this->data=$this->link->query($this->querys);
}
function view_complete_installation(){
$this->querys="SELECT * from complete_installation ";
return $this->data=$this->link->query($this->querys);
 }
function view_complete_installation_payment(){
$this->querys="SELECT * from complete_installation_payment";
return $this->data=$this->link->query($this->querys);
 }
function view_permission_levels(){
$this->querys="SELECT * from permission_levels ";
return $this->data=$this->link->query($this->querys);
 }
function view_province(){
$this->querys="SELECT * from province";
return $this->data=$this->link->query($this->querys);
 }
function view_customer_status_history(){
$this->querys="SELECT * from customer_status_history";
return $this->data=$this->link->query($this->querys);
 
}
//lets build our date first 
function return_todaydate(){
$this->date=date("d/m/Y");
return $this->date;
 
}
//now lets build our redirectiring function.php

function redirect_page($url_slug){

  if ($url_slug==="province_save") {
    $this->page="province.php";
    return $this->page;
  }
  elseif ($url_slug==="paroise_save") {
    $this->page="paroise.php";
    return $this->page;
  }
 elseif ($url_slug==="payment_save") {
    $this->page="payment_details.php";
    return $this->page;
  }
  elseif ($url_slug==="main_stock") {
    $this->page="main_stock.php";
    return $this->page;
  }
   elseif ($url_slug==="user_save") {
   $this->page="users.php";
    return $this->page;
  }
   elseif ($url_slug==="assign_kit_installer_save") {
   $this->page="assign_kits_installer.php";
    return $this->page;
  }

   elseif ($url_slug==="customer_save") {
    $this->page="customers.php";
    return $this->page;
  }
   elseif ($url_slug==="permissions_save") {
   $this->page="persmissions.php";
    return $this->page;
  }
   elseif ($url_slug==="district_save") {
    $this->page="district.php";
    return $this->page;
  }
   elseif ($url_slug==="customer_details_save") {
    $this->page="customer_details.php";
    return $this->page;
  }
   elseif ($url_slug==="set_permission_save") {
   $this->page="set_permission.php";
    return $this->page;
  }
  elseif ($url_slug==="payment_method_save") {
   $this->page="payment_mode.php";
    return $this->page;
  }
elseif ($url_slug==="system_module") {
   $this->page="system_module.php";
    return $this->page;
  }
elseif ($url_slug==="permission_level_save") {
   $this->page="permission_level.php";
    return $this->page;
  }
elseif ($url_slug==="permission_save") {
   $this->page="permission.php";
    return $this->page;
  }
elseif ($url_slug==="complete_installation_save") {
   $this->page="complete_installation.php";
    return $this->page;
  }
  else
  {
    $this->page="index.php";
    return $this->page;
  }

}

function message($url,$response){

 if ($response===true) {
if ($url==="province_save") {
    $this->message="province";
     return $this->msg="You have successfully recorded a new".$this->message." you can now continue ";
  }
  elseif ($url_slug==="paroise_save") {
    $this->message="paroise";
   return $this->msg="You have successfully recorded a new".$this->message." you can now continue ";
  }
   elseif ($url_slug==="user_save") {
   $this->message="users";
   return $this->msg="You have successfully recorded a new".$this->message." you can now continue ";
  }
  elseif ($url_slug==="payment_save") {
    $this->message="Payment Mode";
   return $this->msg="You have successfully recorded a new".$this->message." you can now continue ";
  }
   elseif ($url_slug==="assign_kits_installer.php") {
   $this->message="Kits assignment";
   return $this->msg="You have successfully recorded a new".$this->message." you can now continue ";
  }


   elseif ($url_slug==="customer_save") {
    $this->message="customers";
   return $this->msg="You have successfully recorded a new".$this->message." you can now continue ";
  }
   elseif ($url_slug==="permissions_save") {
   $this->message="persmissions";
   return $this->msg="You have successfully recorded a new".$this->message." you can now continue ";
  }
   elseif ($url_slug==="district_save") {
    $this->message="district";
   return $this->msg="You have successfully recorded a new".$this->message." you can now continue ";
  }
   elseif ($url_slug==="customer_details_save") {
    $this->message="customer_details";
   return $this->msg="You have successfully recorded a new".$this->message." you can now continue ";
  }
   elseif ($url_slug==="set_permission_save") {
   $this->message="set_permission";
   return $this->msg="You have successfully recorded a new".$this->message." you can now continue ";
  }
  elseif ($url_slug==="payment_method_save") {
   $this->message="payment_mode";
   return $this->msg="You have successfully recorded a new".$this->message." you can now continue ";
  }
elseif ($url_slug==="system_module") {
   $this->message="system_module";
   return $this->msg="You have successfully recorded a new".$this->message." you can now continue ";
  }
elseif ($url_slug==="permission_level_save") {
   $this->message="permission_level";
   return $this->msg="You have successfully recorded a new".$this->message." you can now continue ";
  }

elseif ($url_slug==="complete_installation_save") {
   $this->message="complete_installation";
   return $this->msg="You have successfully recorded a new".$this->message." you can now continue ";
  }
  else
  {
       return $this->msg="we can not seem to get where you are from please try to login again !!";
  }
 }
 else
 {
  if ($url==="province_save") {
    $this->message="province";
     return $this->msg="You have Failed recorded a new".$this->message." you can now continue ";
  }
  elseif ($url_slug==="paroise_save") {
    $this->message="paroise";
   return $this->msg="You have Failed recorded a new".$this->message." you can now continue ";
  }
   elseif ($url_slug==="user_save") {
   $this->message="users";
   return $this->msg="You have Failed recorded a new".$this->message." you can now continue ";
  }
   elseif ($url_slug==="customer_save") {
    $this->message="customers";
   return $this->msg="You have Failed recorded a new".$this->message." you can now continue ";
  }
   elseif ($url_slug==="permissions_save") {
   $this->message="persmissions";
   return $this->msg="You have Failed recorded a new".$this->message." you can now continue ";
  }
   elseif ($url_slug==="district_save") {
    $this->message="district";
   return $this->msg="You have Failed recorded a new".$this->message." you can now continue ";
  }
   elseif ($url_slug==="customer_details_save") {
    $this->message="customer_details";
   return $this->msg="You have Failed recorded a new".$this->message." you can now continue ";
  }
   elseif ($url_slug==="set_permission_save") {
   $this->message="set_permission";
   return $this->msg="You have Failed recorded a new".$this->message." you can now continue ";
  }
  elseif ($url_slug==="payment_method_save") {
   $this->message="payment_mode";
   return $this->msg="You have Failed recorded a new".$this->message." you can now continue ";
  }
elseif ($url_slug==="system_module") {
   $this->message="system_module";
   return $this->msg="You have Failed recorded a new".$this->message." you can now continue ";
  }
elseif ($url_slug==="permission_level_save") {
   $this->message="permission_level";
   return $this->msg="You have Failed recorded a new".$this->message." you can now continue ";
  }

elseif ($url_slug==="complete_installation_save") {
   $this->message="complete_installation";
   return $this->msg="You have Failed recorded a new".$this->message." you can now continue ";
  }
  else
  {
       return $this->msg="we can not seem to get where you are from, Please try to login again !!";
  }
 }

}




//Lets upload the pictures
function upload($img_url,$temp) {
$target_dir = "media/";
$target_file = $target_dir . basename($img_url,$temp);
move_uploaded_file($_FILES["$temp"]["tmp_name"], $target_file);
return $target_file;
}

}


?>