<?php
function get_last_message($conv_id){
	$conn = new mysqli("localhost","root","","questadmin");

$user="SELECT * FROM conversation_reply where cid='$conv_id'";
$data=$conn->query($user);
if ($data->num_rows > 0) {

$row=$data->fetch_assoc();
return $row['reply'];

}
else
{
	return false;
}


}
function get_last_date($conv_id){
	$conn = new mysqli("localhost","root","","questadmin");

$user="SELECT * FROM conversation_reply where cid='$conv_id'";
$data=$conn->query($user);
if ($data->num_rows > 0) {

$row=$data->fetch_assoc();
$newDate = date("d M Y", strtotime($row['date_added']));
return $newDate;

}
else
{
	return false;
}


}




function image($myid){
	$conn = new mysqli("localhost","root","","questadmin");

$user="SELECT * FROM user where userid='$myid'";
$data=$conn->query($user);
if ($data->num_rows > 0) {

$row=$data->fetch_assoc();
$newDate = $row['bg_imagelocation'];
return $newDate;

}
else
{
	return false;
}


}



function get_conversation($myid){
$conn = new mysqli("localhost","root","","questadmin");

$query="SELECT * FROM conversation_reply where ";


}




function get_username($myid){
	$conn = new mysqli("localhost","root","","questadmin");

$user="SELECT * FROM user where userid='$conv_id'";
$data=$conn->query($user);
if ($data->num_rows > 0) {

$row=$data->fetch_assoc();
return $row['name'];

}
else
{
	return false;
}


}




















   /* <div class="single_message_chat">
                                    <div class="message_pre_left">
                                        <div class="message_preview_thumb">
                                            <img src="<?php echo image($myid);?>" alt="">
                                        </div>
                                        <div class="messges_info">
                                            <h4>Travor James</h4>
                                            <p>Yesterday at 6.33 pm</p>
                                        </div>
                                    </div>
                                    <div class="message_content_view red_border">
                                        <p>
                                            Dear KK,
                                            <br>
                                            Thank you for your update.
                                        

                                  
                                        </p>
                                    </div>
                                </div>
                                <div class="single_message_chat sender_message">
                                    <div class="message_pre_left">
                                        <div class="messges_info">
                                            <h4>Agatha Kristy</h4>
                                            <p>Yesterday at 6.33 pm</p>
                                        </div>
                                        <div class="message_preview_thumb">
                                            <img src="img/messages/2.jpg" alt="">
                                        </div>
                                    </div>
                                    <div class="message_content_view">
                                        <p>
                                        

                                            <span>
                                                We do not sell or share your details without your permission. Find
                                                out
                                                more
                                                in our Privacy Policy. Your username, email and password can be
                                                updated
                                                via
                                                your Codepixar Account settings.
                                         
                                            </span>
                                  
                                        </p>
                                    </div>
                                </div>*/


?>