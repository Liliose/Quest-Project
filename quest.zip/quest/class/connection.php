<?php

$conn = new mysqli("localhost","root","","questadmin");

// Check connection
if ($conn -> connect_errno) {
  echo "Failed to connect to MySQL: " . $conn -> connect_error;
  exit();
}
//{{ translate('Current Package')}}: {{ $seller_package->getTranslation('name') }}
?>