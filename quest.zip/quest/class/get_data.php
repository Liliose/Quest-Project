<?php
$conv_id=$_GET['conv_id'];

function get_username($myid){
	$conn = new mysqli("localhost","root","","questadmin");

$user="SELECT * FROM user where userid='$myid'";
$data=$conn->query($user);
if ($data->num_rows > 0) {

$row=$data->fetch_assoc();
return $row['name'];

}
else
{
	return false;
}


}

function images($myid){
	$conn = new mysqli("localhost","root","","questadmin");

$user="SELECT * FROM user where userid='$myid'";
$data=$conn->query($user);
if ($data->num_rows > 0) {

$row=$data->fetch_assoc();
$newDate = $row['bg_imagelocation'];
return $newDate;

}
else
{
	return false;
}


}
include 'connection.php';
function determine_user($user_sending,$myid){
if ($myid===$user_sending) {
	return "red_border";
}
else
{
	return "";
}

}

function determine_users($user_sending,$myid){
if ($myid===$user_sending) {
	return "sender_message";
}
else
{
	return "";
}

}




/*
$conn = new mysqli("localhost","root","","questadmin");*/

$query="SELECT * FROM conversation_reply where cid='$conv_id'";
$data=$conn->query($query);
if ($data->num_rows > 0) {
while ($row=$data->fetch_assoc()) {
$id=$conv_id;
$myid="156980859299";
$user_sending=$row['user_sending'];
$message=$row['reply'];
$date_sent=date('h:i A', strtotime($row['date_added']));

echo "<div class=\"single_message_chat ".determine_users($user_sending,$myid)."\">
                                    <div class=\"message_pre_left\">
                                        <div class=\"messges_info\">
                                            <h4>".get_username($myid)."</h4>
                                            <p>$date_sent</p>
                                        </div>
                                        <div class=\"message_preview_thumb\">
                                            <img src=\" ".images($myid)."\" alt=\"\">
                                        </div>
                                    </div>
                                    <div class=\"message_content_view ". determine_user($user_sending,$myid)."\">
                                        <p>
                                        

                                            <span>
                                     
                                                $message
                                         
                                            </span>
                                  
                                        </p>
                                    </div>
</div>";

}
}

/*echo $conv_id;*/
?>