-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 02, 2021 at 09:34 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `questadmin`
--

-- --------------------------------------------------------

--
-- Table structure for table `about_info`
--

CREATE TABLE `about_info` (
  `id` int(255) NOT NULL,
  `userid` varchar(300) NOT NULL,
  `year` varchar(300) NOT NULL,
  `company` varchar(300) NOT NULL,
  `title` varchar(300) NOT NULL,
  `description` longtext NOT NULL,
  `type` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `about_info`
--

INSERT INTO `about_info` (`id`, `userid`, `year`, `company`, `title`, `description`, `type`) VALUES
(1, '309060086578', '2015-2020', 'Working in Pixel Inc. Ltd', 'Web Developper', 'I can do everything related to IT field', 1),
(2, '309060086578', '201-2018', 'Bachelor Degree', 'Computer Programming', 'Programming softwares', 2);

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(255) NOT NULL,
  `adminid` varchar(300) NOT NULL,
  `username` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `name` varchar(300) NOT NULL,
  `email` text NOT NULL,
  `imagelocation` text NOT NULL,
  `tokencode` text NOT NULL,
  `joined` datetime NOT NULL,
  `user_type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `adminid`, `username`, `password`, `name`, `email`, `imagelocation`, `tokencode`, `joined`, `user_type`) VALUES
(1, '1471436678', 'Admin', '$2y$10$nx1CghcPCwAOwxo8UP.pSeP5EJ5OsUPlUmctLBFO54/Qe.hy1kBcO', 'Questgis main admin', 'admin@pixel.rw', 'EJxBQbStvXjl6y.png', '', '2016-08-17 14:24:38', 1);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(255) NOT NULL,
  `name` varchar(300) NOT NULL,
  `imagelocation` varchar(300) NOT NULL,
  `parent_category_id` varchar(111) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `imagelocation`, `parent_category_id`) VALUES
(34, 'Environment and Natural Resources Management', '21.05.10.16.55-1620658529.2141-14679134.jpg', '1'),
(35, 'Engineering planning', '21.05.10.16.55-1620658557.2507-54534065.jpg', '1'),
(36, 'Smart agriculture', '21.05.10.16.56-1620658574.8276-44678488.jpg', '1'),
(38, 'Humanitarian operations and response', '21.05.10.16.57-1620658635.7125-72247020.jpg', '1'),
(39, 'Disaster management ', '21.05.10.16.57-1620658666.4163-49901095.jpg', '1'),
(40, 'Urban and Rural Planning ', '21.05.11.10.33-1620722007.4263-3096821.jpg', '1'),
(41, 'Land Information Management', '21.05.10.16.58-1620658732.296-77242960.jpg', '1'),
(42, 'Banking ', '21.05.10.16.59-1620658753.895-27548321.jpg', '1'),
(43, 'Telecommunications ', '21.05.10.16.59-1620658773.7088-54266778.jpg', '1'),
(44, 'Health care ', '21.05.10.17.00-1620658810.9982-22792633.jpg', '1'),
(46, 'Population and census', '21.05.10.17.01-1620658880.7662-66857545.jpg', '1'),
(48, 'Election planning and operations', '21.05.10.17.02-1620658939.5012-89575930.jpg', '1'),
(49, 'Crime and security ', '21.05.10.17.02-1620658978.8108-3056471.jpg', '1'),
(50, 'Cadastral survey', '21.05.10.17.03-1620659012.1149-60056400.jpg', '2'),
(51, 'Topographic survey', '21.05.10.17.04-1620659040.4579-14284624.jpg', '2'),
(52, 'Mining survey', '21.05.10.17.04-1620659063.509-83090698.jpg', '2'),
(55, 'Hydrographic and bathymetry', '21.05.10.17.05-1620659150.1403-51247457.jpg', '2'),
(56, 'Geodetic survey and GNSS', '21.05.10.17.06-1620659173.4167-67374129.jpg', '2'),
(58, 'Road construction survey', '21.05.10.17.07-1620659223.3864-72672832.jpg', '2'),
(60, 'Structural monitoring; bridge, High Rise budding, Towers, etc.', '21.05.10.17.17-1620659868.5068-80384707.jpg', '2');

-- --------------------------------------------------------

--
-- Table structure for table `category_gis`
--

CREATE TABLE `category_gis` (
  `id` int(111) NOT NULL,
  `cat_name` varchar(111) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `conversation`
--

CREATE TABLE `conversation` (
  `id` int(255) NOT NULL,
  `cid` varchar(300) NOT NULL,
  `projectid` varchar(300) NOT NULL,
  `freelancerid` varchar(300) NOT NULL,
  `clientid` varchar(300) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `conversation`
--

INSERT INTO `conversation` (`id`, `cid`, `projectid`, `freelancerid`, `clientid`, `date_added`) VALUES
(1, 'Q1jtJdhTXML9Or', 'f3GirOMtH8Luct', '712294760317', '156980859299', '2021-04-05 13:13:03'),
(2, 'JSltoHWUJKRDzs', 'ygwMbs4TGCn3Jb', '309060086578', '156980859299', '2021-04-08 16:24:42'),
(3, 'WPmdmw9lGGZ5D8', 'MgtTAUjrd8nNtv', '173733110050', '608879165476', '2021-04-13 05:37:53'),
(4, 'dLRGZWT6nR40qt', '1iGlBywqFqGQWW', '173733110050', '156980859299', '2021-04-25 20:09:50'),
(5, 'D9egYdNJEu2RGh', 'WlJ8du9zhzyqW8', '309060086578', '156980859299', '2021-04-26 18:16:28'),
(6, 'e1RhMBpynTZLRG', 'WlJ8du9zhzyqW8', '712294760317', '156980859299', '2021-05-06 15:07:01'),
(7, 'oskI3PA9hLSYC2', '1V6uD4iI8tKa04', '309060086578', '156980859299', '2021-05-08 14:16:22'),
(8, 'vn3qvyBHYh1GJq', 'MzIxp2mbWFvTTd', '712294760317', '156980859299', '2021-05-08 19:03:05'),
(9, 'sxkk03JSVOTSoX', 'Up5drnBJ2YlWxk', '712294760317', '156980859299', '2021-05-20 13:16:35');

-- --------------------------------------------------------

--
-- Table structure for table `conversation_reply`
--

CREATE TABLE `conversation_reply` (
  `id` int(255) NOT NULL,
  `cid` varchar(300) NOT NULL,
  `projectid` varchar(300) NOT NULL,
  `nid` varchar(300) NOT NULL,
  `user_sending` varchar(300) NOT NULL,
  `reply` longtext NOT NULL,
  `read_status` tinyint(4) NOT NULL,
  `date_added` datetime NOT NULL,
  `admin_verified` varchar(111) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `conversation_reply`
--

INSERT INTO `conversation_reply` (`id`, `cid`, `projectid`, `nid`, `user_sending`, `reply`, `read_status`, `date_added`, `admin_verified`) VALUES
(1, 'Q1jtJdhTXML9Or', 'f3GirOMtH8Luct', '2', '309060086578', 'I can do all it well', 1, '2021-04-05 13:13:03', '0'),
(2, 'Q1jtJdhTXML9Or', 'f3GirOMtH8Luct', '3', '156980859299', 'Hi Pixel Inc. Ltd, can you please reduce an amount', 1, '2021-04-05 13:19:45', '0'),
(3, 'JSltoHWUJKRDzs', 'ygwMbs4TGCn3Jb', '8', '309060086578', 'Please I have an experience for this work', 1, '2021-04-08 16:24:43', '0'),
(4, 'JSltoHWUJKRDzs', 'ygwMbs4TGCn3Jb', '9', '156980859299', 'can you please reduce some amount', 1, '2021-04-08 16:26:59', '0'),
(5, 'WPmdmw9lGGZ5D8', 'MgtTAUjrd8nNtv', '14', '173733110050', 'this is my proposal', 0, '2021-04-13 05:37:53', '0'),
(6, 'dLRGZWT6nR40qt', '1iGlBywqFqGQWW', '17', '173733110050', 'I can do this', 1, '2021-04-25 20:09:50', '0'),
(7, 'D9egYdNJEu2RGh', 'WlJ8du9zhzyqW8', '19', '309060086578', 'testing comment', 1, '2021-04-26 18:16:29', '0'),
(8, 'e1RhMBpynTZLRG', 'WlJ8du9zhzyqW8', '21', '712294760317', 'test', 1, '2021-05-06 15:07:02', '0'),
(9, 'oskI3PA9hLSYC2', '1V6uD4iI8tKa04', '23', '309060086578', 'testing proposal', 1, '2021-05-08 14:16:22', '0'),
(10, 'oskI3PA9hLSYC2', '1V6uD4iI8tKa04', '24', '156980859299', 'testing message', 1, '2021-05-08 14:18:53', '0'),
(11, 'oskI3PA9hLSYC2', '1V6uD4iI8tKa04', '25', '156980859299', 'testing message', 1, '2021-05-08 14:19:09', '0'),
(12, 'vn3qvyBHYh1GJq', 'MzIxp2mbWFvTTd', '27', '712294760317', 'I can do it in 1 month.', 1, '2021-05-08 19:03:05', '0'),
(13, 'vn3qvyBHYh1GJq', 'MzIxp2mbWFvTTd', '28', '156980859299', 'Hi can have the invoice?', 1, '2021-05-08 19:04:38', '0'),
(14, 'vn3qvyBHYh1GJq', 'MzIxp2mbWFvTTd', '29', '712294760317', 'yes we can provide the invoice for you no problem', 1, '2021-05-08 19:07:07', '0'),
(15, 'vn3qvyBHYh1GJq', 'MzIxp2mbWFvTTd', '31', '712294760317', 'submitted', 1, '2021-05-15 15:01:31', '0'),
(16, 'sxkk03JSVOTSoX', 'Up5drnBJ2YlWxk', '33', '712294760317', 'testing message from freelancer', 1, '2021-05-20 13:16:36', '0'),
(17, 'sxkk03JSVOTSoX', 'Up5drnBJ2YlWxk', '34', '156980859299', 'this is too much', 1, '2021-05-20 13:19:26', '0'),
(18, 'sxkk03JSVOTSoX', 'Up5drnBJ2YlWxk', '35', '712294760317', 'yes we can accept it ', 1, '2021-05-20 13:35:58', '0'),
(19, 'Q1jtJdhTXML9Or', 'f3GirOMtH8Luct', '2045', '156980859299', 'dfgdfg', 0, '2021-05-21 17:16:23', '0');

-- --------------------------------------------------------

--
-- Table structure for table `currency`
--

CREATE TABLE `currency` (
  `id` int(255) NOT NULL,
  `currency_code` varchar(300) NOT NULL,
  `currency_name` varchar(300) NOT NULL,
  `currency_symbol` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `currency`
--

INSERT INTO `currency` (`id`, `currency_code`, `currency_name`, `currency_symbol`) VALUES
(1, 'USD', 'US Dollar', '$'),
(2, 'AUD', 'Australian dollar', '$'),
(3, 'BRL', 'Brazilian real', 'R$'),
(5, 'CAD', 'Canadian dollar', '$'),
(6, 'CLP', 'Chilean peso', '$'),
(7, 'CNY', 'Chinese yuan', 'Â¥'),
(8, 'DKK', 'Danish krone', 'kr'),
(9, 'EUR', 'Euro', 'â‚¬'),
(10, 'HKD', 'Hong Kong dollar', '$'),
(11, 'INR', 'Indian rupee', 'â‚¹'),
(12, 'IDR', 'Indonesian rupiah', 'Rp'),
(13, 'ILS', 'Israeli new shekel', 'â‚ª'),
(14, 'JPY', 'Japanese yen', 'Â¥'),
(15, 'KES', 'Kenyan shilling', 'Ksh'),
(16, 'KPW', 'North Korean won', 'â‚©'),
(17, 'KRW', 'South Korean won', 'â‚©'),
(18, 'MYR', 'Malaysian ringgit', 'RM'),
(19, 'MXN', 'Mexican peso', '$'),
(20, 'NZD', 'New Zealand dollar', '$'),
(21, 'NOK', 'Norwegian krone', 'kr'),
(22, 'PKR', 'Pakistani rupee', 'â‚¨'),
(23, 'PLN', 'Polish zÅ‚oty', 'zÅ‚'),
(24, 'PHP', 'Philippine peso', 'â‚±'),
(25, 'RUB', 'Russian ruble', 'â‚½'),
(26, 'SGD', 'Singapore dollar', '$'),
(27, 'ZAR', 'South African rand', 'R'),
(28, 'SEK', 'Swedish krona', 'kr'),
(29, 'CHF', 'Swiss franc', 'Fr'),
(30, 'TWD', 'New Taiwan dollar', '$'),
(31, 'TRY', 'Turkish lira', 'â‚º'),
(32, 'AED', 'United Arab Emirates dirham', 'Ø¯.Ø¥'),
(39, 'GG', 'GG', '('),
(40, 'GG', 'Mexican', '*'),
(41, 'GG', 'GG', '6'),
(42, 'Frw', 'Rwandan Francs', 'Frw');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(255) NOT NULL,
  `name` varchar(300) NOT NULL,
  `title` varchar(300) NOT NULL,
  `quote` mediumtext NOT NULL,
  `imagelocation` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dispute_conversation`
--

CREATE TABLE `dispute_conversation` (
  `id` int(255) NOT NULL,
  `cid` varchar(300) NOT NULL,
  `projectid` varchar(300) NOT NULL,
  `freelancerid` varchar(300) NOT NULL,
  `clientid` varchar(300) NOT NULL,
  `adminid` varchar(300) NOT NULL,
  `action` tinyint(4) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dispute_conversation_reply`
--

CREATE TABLE `dispute_conversation_reply` (
  `id` int(255) NOT NULL,
  `cid` varchar(300) NOT NULL,
  `projectid` varchar(300) NOT NULL,
  `user_sending` varchar(300) NOT NULL,
  `reply` longtext NOT NULL,
  `read_status_freelancer` tinyint(4) NOT NULL,
  `read_status_client` tinyint(4) NOT NULL,
  `read_status_admin` tinyint(4) NOT NULL,
  `is_admin` tinyint(4) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `escrow`
--

CREATE TABLE `escrow` (
  `id` int(255) NOT NULL,
  `proposalid` varchar(300) NOT NULL,
  `projectid` varchar(300) NOT NULL,
  `freelancerid` varchar(300) NOT NULL,
  `clientid` varchar(300) NOT NULL,
  `nid` int(70) NOT NULL,
  `budget` decimal(15,2) NOT NULL,
  `action` tinyint(4) NOT NULL,
  `read_status` tinyint(4) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `escrow`
--

INSERT INTO `escrow` (`id`, `proposalid`, `projectid`, `freelancerid`, `clientid`, `nid`, `budget`, `action`, `read_status`, `date_added`) VALUES
(1, '1', 'f3GirOMtH8Luct', '309060086578', '156980859299', 4, '500.00', 2, 1, '2021-04-05 13:24:02'),
(2, '2', 'ygwMbs4TGCn3Jb', '309060086578', '156980859299', 10, '400000.00', 2, 1, '2021-04-08 16:40:01');

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE `faq` (
  `id` int(255) NOT NULL,
  `question` varchar(300) NOT NULL,
  `answer` longtext NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` int(255) NOT NULL,
  `projectid` varchar(300) NOT NULL,
  `user_sending` varchar(300) NOT NULL,
  `user_receiving` varchar(300) NOT NULL,
  `nid` varchar(300) NOT NULL,
  `fileupload` varchar(300) NOT NULL,
  `type` varchar(300) NOT NULL,
  `extension` varchar(300) NOT NULL,
  `size` varchar(300) NOT NULL,
  `read_status` tinyint(4) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `projectid`, `user_sending`, `user_receiving`, `nid`, `fileupload`, `type`, `extension`, `size`, `read_status`, `date_added`) VALUES
(1, 'eUSPl8YeQh', '228145236254', '981686315672', '37', '1ywL15JJUgimg_3.jpg', 'image/jpeg', 'jpg', '32.578125', 1, '2019-11-21 10:38:02'),
(2, 'Wm0W6YvzLr', '431974897102', '715478889450', '43', 'euxmlRR6VWlogo.svg', 'image/svg+xml', 'svg', '5.4638671875', 1, '2019-11-21 10:38:02'),
(3, 'Wm0W6YvzLr', '715478889450', '431974897102', '44', 'tAONCakoYjlogo-mini.svg', 'image/svg+xml', 'svg', '1.9599609375', 1, '2019-11-21 10:38:02'),
(6, 'uJCOYwXrdO', '329616019298', '305378125552', '54', 'svLZVKb3hIindex.html', 'text/html', 'html', '5.59765625', 1, '2019-11-21 10:38:02'),
(7, 'uJCOYwXrdO', '305378125552', '329616019298', '55', 'Ps6kWNMcM9index.html', 'text/html', 'html', '5.59765625', 1, '2019-11-21 10:38:02'),
(8, 'bVbRUo36To', '296594131506', '434155361070', '71', 'wrr45XlIov1.png', 'image/png', 'png', '339.392578125', 1, '2019-11-21 10:38:02'),
(9, 'bVbRUo36To', '434155361070', '296594131506', '73', 'MssmvGuFaAindex.html', 'text/html', 'html', '4.9736328125', 0, '2019-11-21 10:38:02'),
(10, 'fi47zFrW8s', '969406884108', '228145236254', '84', 'vdTmHvR5P51.jpg', 'image/jpeg', 'jpg', '52.9609375', 1, '2019-11-21 10:38:02'),
(13, 'eUSPl8YeQh', '981686315672', '228145236254', '128', 'SO3kMxokWOBx1W.png', 'image/png', 'png', '9.3388671875', 1, '2019-11-29 07:13:19'),
(16, 'eUSPl8YeQh', '981686315672', '228145236254', '131', 'zUH8WMpiEasGdd.jpg', 'image/jpeg', 'jpg', '54.375', 1, '2019-11-29 11:40:05'),
(18, 'eUSPl8YeQh', '228145236254', '981686315672', '133', 'KF8FHt06l1jqI7.png', 'image/png', 'png', '6.234375', 1, '2019-11-29 12:04:07'),
(19, 'e2qj4OYYIs', '199476311866', '188158648562', '147', 'ceddull0TMKCNg.jpg', 'image/jpeg', 'jpg', '26.0009765625', 0, '2019-12-02 13:18:50'),
(20, 'f3GirOMtH8Luct', '309060086578', '156980859299', '5', 'qAbVnhfjtg6Ng3.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'docx', '37.421875', 1, '2021-04-05 13:26:12'),
(21, 'ygwMbs4TGCn3Jb', '309060086578', '156980859299', '11', 'X8X42Yqb5C5Jjq.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'docx', '15.0693359375', 1, '2021-04-08 16:41:05'),
(22, 'f3GirOMtH8Luct', '156980859299', '309060086578', '15', 'h5SfEqglu8roHr.pdf', 'application/pdf', 'pdf', '381.09765625', 1, '2021-04-23 15:34:36');

-- --------------------------------------------------------

--
-- Table structure for table `funds`
--

CREATE TABLE `funds` (
  `id` int(255) NOT NULL,
  `paymentid` varchar(300) NOT NULL,
  `clientid` varchar(300) NOT NULL,
  `type` varchar(300) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `transaction_fee` decimal(15,2) NOT NULL,
  `complete` tinyint(4) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `funds`
--

INSERT INTO `funds` (`id`, `paymentid`, `clientid`, `type`, `amount`, `transaction_fee`, `complete`, `date_added`) VALUES
(1, 'BK45845RC', '156980859299', 'Bank Transfer', '1000.00', '2.50', 1, '2021-04-05 12:10:17'),
(2, '6789JMNHG', '156980859299', 'Bank Transfer', '400000.00', '2.50', 1, '2021-04-08 16:35:49'),
(25, 'Quest26014231', '156980859299', 'MTN RWANDA', '100.00', '5.00', 1, '2021-04-26 01:42:31'),
(26, 'Quest26015315', '156980859299', 'MTN RWANDA', '100.00', '5.00', 1, '2021-04-26 01:53:15'),
(27, 'Quest26015733', '156980859299', 'MTN RWANDA', '100.00', '5.00', 1, '2021-04-26 01:57:33'),
(28, 'Quest26020004', '156980859299', 'MTN RWANDA', '100.00', '5.00', 1, '2021-04-26 02:00:04'),
(29, 'Quest26022125', '156980859299', 'MTN RWANDA', '100.00', '5.00', 1, '2021-04-26 02:21:25'),
(30, 'Quest27015647', '', '', '0.00', '0.00', 1, '2021-04-27 01:56:47'),
(31, 'Quest27030349', '', '', '0.00', '0.00', 1, '2021-04-27 03:03:49'),
(32, 'Quest27084934', '', '', '0.00', '0.00', 1, '2021-04-27 08:49:34'),
(33, 'Quest28042953', '', '', '0.00', '0.00', 1, '2021-04-28 04:29:53'),
(34, 'Quest28055207', '', '', '0.00', '0.00', 1, '2021-04-28 05:52:07'),
(35, 'Quest28094500', '', '', '0.00', '0.00', 0, '2021-04-28 09:45:00'),
(36, 'Quest03124315', '', '', '0.00', '0.00', 1, '2021-05-03 12:43:15'),
(37, 'Quest03040457', '', '', '0.00', '0.00', 1, '2021-05-03 04:04:57'),
(38, 'Quest03091209', '', '', '0.00', '0.00', 1, '2021-05-03 09:12:09'),
(39, 'Quest03115446', '', '', '0.00', '0.00', 1, '2021-05-03 11:54:46'),
(40, 'Quest03033604', '', '', '0.00', '0.00', 1, '2021-05-03 03:36:04'),
(41, 'Quest03080452', '', '', '0.00', '0.00', 1, '2021-05-03 08:04:52'),
(42, 'Quest03092630', '', '', '0.00', '0.00', 1, '2021-05-03 09:26:30'),
(43, 'Quest03113500', '', '', '0.00', '0.00', 1, '2021-05-03 11:35:00'),
(44, 'Quest04025537', '', '', '0.00', '0.00', 1, '2021-05-04 02:55:37'),
(45, 'Quest04041221', '', '', '0.00', '0.00', 1, '2021-05-04 04:12:21'),
(46, 'Quest04060752', '', '', '0.00', '0.00', 1, '2021-05-04 06:07:52'),
(47, 'Quest04072448', '', '', '0.00', '0.00', 1, '2021-05-04 07:24:48'),
(48, 'Quest04023722', '', '', '0.00', '0.00', 1, '2021-05-04 02:37:22'),
(49, 'Quest05030533', '', '', '0.00', '0.00', 1, '2021-05-05 03:05:33'),
(50, 'Quest05032832', '', '', '0.00', '0.00', 1, '2021-05-05 03:28:32'),
(51, 'Quest05064417', '', '', '0.00', '0.00', 1, '2021-05-05 06:44:17'),
(52, 'Quest05073445', '', '', '0.00', '0.00', 1, '2021-05-05 07:34:45'),
(53, 'Quest05093553', '', '', '0.00', '0.00', 1, '2021-05-05 09:35:53'),
(54, 'Quest06035215', '', '', '0.00', '0.00', 1, '2021-05-06 03:52:15'),
(55, 'Quest06044651', '', '', '0.00', '0.00', 1, '2021-05-06 04:46:51'),
(56, 'Quest06014831', '', '', '0.00', '0.00', 1, '2021-05-06 01:48:31'),
(57, 'Quest06075109', '', '', '0.00', '0.00', 1, '2021-05-06 07:51:09'),
(58, 'Quest06100359', '', '', '0.00', '0.00', 1, '2021-05-06 10:03:59'),
(59, 'Quest07021735', '', '', '0.00', '0.00', 1, '2021-05-07 02:17:35'),
(60, 'Quest07022914', '', '', '0.00', '0.00', 1, '2021-05-07 02:29:14'),
(61, 'Quest07023624', '', '', '0.00', '0.00', 1, '2021-05-07 02:36:24'),
(62, 'Quest07045140', '', '', '0.00', '0.00', 1, '2021-05-07 04:51:40'),
(63, 'Quest07072903', '', '', '0.00', '0.00', 1, '2021-05-07 07:29:03'),
(64, 'Quest07093510', '', '', '0.00', '0.00', 1, '2021-05-07 09:35:10'),
(65, 'Quest08124820', '', '', '0.00', '0.00', 1, '2021-05-08 12:48:20'),
(66, 'Quest08010447', '', '', '0.00', '0.00', 1, '2021-05-08 01:04:47'),
(67, 'Quest08014341', '', '', '0.00', '0.00', 1, '2021-05-08 01:43:41'),
(68, 'Quest08025600', '', '', '0.00', '0.00', 1, '2021-05-08 02:56:00'),
(69, 'Quest08065629', '', '', '0.00', '0.00', 1, '2021-05-08 06:56:29'),
(70, 'Quest08111850', '', '', '0.00', '0.00', 1, '2021-05-08 11:18:50'),
(71, 'Quest08095128', '156980859299', 'MTN RWANDA', '100.00', '5.00', 1, '2021-05-08 09:51:28'),
(72, 'Quest08095352', '156980859299', 'MTN RWANDA', '100.00', '5.00', 1, '2021-05-08 09:53:52'),
(73, 'Quest08040526', '', '', '0.00', '0.00', 1, '2021-05-08 04:05:26'),
(74, 'Quest08104354', '', '', '0.00', '0.00', 1, '2021-05-08 10:43:54'),
(75, 'Quest08104549', '', '', '0.00', '0.00', 1, '2021-05-08 10:45:49'),
(76, 'Quest08104720', '', '', '0.00', '0.00', 1, '2021-05-08 10:47:20'),
(77, 'Quest08115211', '', '', '0.00', '0.00', 1, '2021-05-08 11:52:11'),
(78, 'Quest09024926', '', '', '0.00', '0.00', 1, '2021-05-09 02:49:26'),
(79, 'Quest09072355', '', '', '0.00', '0.00', 1, '2021-05-09 07:23:55'),
(80, 'Quest09091745', '', '', '0.00', '0.00', 1, '2021-05-09 09:17:45'),
(81, 'Quest09062222', '', '', '0.00', '0.00', 1, '2021-05-09 06:22:22'),
(82, 'Quest10120246', '', '', '0.00', '0.00', 1, '2021-05-10 12:02:46'),
(83, 'Quest10041223', '', '', '0.00', '0.00', 1, '2021-05-10 04:12:23'),
(84, 'Quest10054556', '', '', '0.00', '0.00', 1, '2021-05-10 05:45:56'),
(85, 'Quest10091624', '', '', '0.00', '0.00', 1, '2021-05-10 09:16:24'),
(86, 'Quest10095617', '', '', '0.00', '0.00', 1, '2021-05-10 09:56:17'),
(87, 'Quest10122850', '', '', '0.00', '0.00', 1, '2021-05-10 12:28:50'),
(88, 'Quest11010912', '', '', '0.00', '0.00', 1, '2021-05-11 01:09:12'),
(89, 'Quest11045311', '', '', '0.00', '0.00', 1, '2021-05-11 04:53:11'),
(90, 'Quest11051244', '', '', '0.00', '0.00', 1, '2021-05-11 05:12:44'),
(91, 'Quest12024711', '', '', '0.00', '0.00', 1, '2021-05-12 02:47:11'),
(92, 'Quest12031450', '', '', '0.00', '0.00', 1, '2021-05-12 03:14:50'),
(93, 'Quest12084437', '', '', '0.00', '0.00', 1, '2021-05-12 08:44:37'),
(94, 'Quest12072722', '', '', '0.00', '0.00', 1, '2021-05-12 07:27:22'),
(95, 'Quest13024923', '', '', '0.00', '0.00', 1, '2021-05-13 02:49:23'),
(96, 'Quest13104350', '', '', '0.00', '0.00', 1, '2021-05-13 10:43:50'),
(97, 'Quest13010903', '', '', '0.00', '0.00', 1, '2021-05-13 01:09:03'),
(98, 'Quest13020021', '', '', '0.00', '0.00', 1, '2021-05-13 02:00:21'),
(99, 'Quest13031719', '', '', '0.00', '0.00', 1, '2021-05-13 03:17:19'),
(100, 'Quest13043111', '', '', '0.00', '0.00', 1, '2021-05-13 04:31:11'),
(101, 'Quest13110531', '', '', '0.00', '0.00', 1, '2021-05-13 11:05:31'),
(102, 'Quest14043304', '', '', '0.00', '0.00', 1, '2021-05-14 04:33:04'),
(103, 'Quest14043807', '', '', '0.00', '0.00', 1, '2021-05-14 04:38:07'),
(104, 'Quest14080242', '', '', '0.00', '0.00', 1, '2021-05-14 08:02:42'),
(105, 'Quest14100823', '', '', '0.00', '0.00', 1, '2021-05-14 10:08:23'),
(106, 'Quest15024722', '', '', '0.00', '0.00', 1, '2021-05-15 02:47:22'),
(107, 'Quest15052647', '', '', '0.00', '0.00', 1, '2021-05-15 05:26:47'),
(108, 'Quest15111738', '', '', '0.00', '0.00', 1, '2021-05-15 11:17:38'),
(109, 'Quest16123721', '', '', '0.00', '0.00', 1, '2021-05-16 12:37:21'),
(110, 'Quest16030719', '', '', '0.00', '0.00', 1, '2021-05-16 03:07:19'),
(111, 'Quest16053557', '', '', '0.00', '0.00', 1, '2021-05-16 05:35:57'),
(112, 'Quest16041122', '', '', '0.00', '0.00', 1, '2021-05-16 04:11:22'),
(113, 'Quest17010744', '', '', '0.00', '0.00', 1, '2021-05-17 01:07:44'),
(114, 'Quest17053741', '', '', '0.00', '0.00', 1, '2021-05-17 05:37:41'),
(115, 'Quest17100407', '', '', '0.00', '0.00', 1, '2021-05-17 10:04:07'),
(116, 'Quest17114027', '', '', '0.00', '0.00', 1, '2021-05-17 11:40:27'),
(117, 'Quest18011225', '', '', '0.00', '0.00', 1, '2021-05-18 01:12:25'),
(118, 'Quest18023747', '', '', '0.00', '0.00', 1, '2021-05-18 02:37:47'),
(119, 'Quest19123629', '', '', '0.00', '0.00', 1, '2021-05-19 12:36:29'),
(120, 'Quest19110836', '', '', '0.00', '0.00', 1, '2021-05-19 11:08:36'),
(121, 'Quest19111549', '', '', '0.00', '0.00', 1, '2021-05-19 11:15:49'),
(122, 'Quest19024149', '', '', '0.00', '0.00', 1, '2021-05-19 02:41:49'),
(123, 'Quest19041717', '', '', '0.00', '0.00', 1, '2021-05-19 04:17:17'),
(124, 'Quest20085333', '', '', '0.00', '0.00', 1, '2021-05-20 08:53:33'),
(125, 'Quest20024212', '', '', '0.00', '0.00', 1, '2021-05-20 02:42:12'),
(126, 'Quest20035759', '', '', '0.00', '0.00', 1, '2021-05-20 03:57:59'),
(127, 'Quest20035838', '', '', '0.00', '0.00', 1, '2021-05-20 03:58:38'),
(128, 'Quest20040600', '', '', '0.00', '0.00', 1, '2021-05-20 04:06:00'),
(129, 'Quest20044340', '', '', '0.00', '0.00', 1, '2021-05-20 04:43:40'),
(130, 'Quest20111903', '', '', '0.00', '0.00', 1, '2021-05-20 11:19:03'),
(131, 'Quest21022914', '', '', '0.00', '0.00', 1, '2021-05-21 02:29:14'),
(132, 'Quest21044419', '', '', '0.00', '0.00', 1, '2021-05-21 04:44:19'),
(133, 'Quest21071426', '', '', '0.00', '0.00', 1, '2021-05-21 07:14:26'),
(134, 'Quest21115237', '', '', '0.00', '0.00', 1, '2021-05-21 11:52:37'),
(135, 'Quest21014502', '', '', '0.00', '0.00', 1, '2021-05-21 01:45:02'),
(136, 'Quest21014510', '', '', '0.00', '0.00', 1, '2021-05-21 01:45:10'),
(137, 'Quest21044851', '', '', '0.00', '0.00', 1, '2021-05-21 04:48:51'),
(138, 'Quest22034233', '', '', '0.00', '0.00', 1, '2021-05-22 03:42:33'),
(139, 'Quest23084919', '', '', '0.00', '0.00', 1, '2021-05-23 08:49:19'),
(140, 'Quest23104310', '', '', '0.00', '0.00', 1, '2021-05-23 10:43:10'),
(141, 'Quest23102752', '', '', '0.00', '0.00', 1, '2021-05-23 10:27:52'),
(142, 'Quest24020332', '', '', '0.00', '0.00', 1, '2021-05-24 02:03:32'),
(143, 'Quest24073035', '', '', '0.00', '0.00', 1, '2021-05-24 07:30:35'),
(144, 'Quest24113842', '', '', '0.00', '0.00', 1, '2021-05-24 11:38:42'),
(145, 'Quest25013601', '', '', '0.00', '0.00', 1, '2021-05-25 01:36:01'),
(146, 'Quest25102303', '', '', '0.00', '0.00', 1, '2021-05-25 10:23:03'),
(147, 'Quest26121158', '', '', '0.00', '0.00', 1, '2021-05-26 12:11:58'),
(148, 'Quest26092038', '', '', '0.00', '0.00', 1, '2021-05-26 09:20:38');

-- --------------------------------------------------------

--
-- Table structure for table `how_it_works`
--

CREATE TABLE `how_it_works` (
  `id` int(255) NOT NULL,
  `title` varchar(300) NOT NULL,
  `description` text NOT NULL,
  `imagelocation` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `how_it_works`
--

INSERT INTO `how_it_works` (`id`, `title`, `description`, `imagelocation`) VALUES
(1, 'Create an Account', 'Creating new account, you have to create it as client or as quest GIS pro', '20.04.08.17.34-1586356476.3597-59576804.png'),
(2, 'Search Jobs', 'Quickly find great jobs posted by our clients. You will post your bid and get hired.', '20.04.08.17.36-1586356599.7975-11605768.png'),
(3, 'Save & Apply', 'With the high quality jobs posted here, it wouldn\'t miss a job befitting your skills.', '20.04.08.17.38-1586356687.4243-27621647.png');

-- --------------------------------------------------------

--
-- Table structure for table `invite`
--

CREATE TABLE `invite` (
  `id` int(255) NOT NULL,
  `projectid` varchar(300) NOT NULL,
  `freelancerid` varchar(300) NOT NULL,
  `clientid` varchar(300) NOT NULL,
  `nid` varchar(300) NOT NULL,
  `action` tinyint(4) NOT NULL,
  `read_status` tinyint(4) NOT NULL,
  `date_declined` datetime NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(255) NOT NULL,
  `projectid` varchar(300) NOT NULL,
  `user_sending` varchar(300) NOT NULL,
  `user_receiving` varchar(300) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `read_status` tinyint(4) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `projectid`, `user_sending`, `user_receiving`, `type`, `read_status`, `date_added`) VALUES
(1, 'f3GirOMtH8Luct', '309060086578', '156980859299', 1, 1, '2021-04-05 13:13:03'),
(2, 'f3GirOMtH8Luct', '309060086578', '156980859299', 2, 1, '2021-04-05 13:13:03'),
(3, 'f3GirOMtH8Luct', '156980859299', '309060086578', 2, 1, '2021-04-05 13:19:45'),
(4, 'f3GirOMtH8Luct', '156980859299', '309060086578', 4, 1, '2021-04-05 13:24:02'),
(5, 'f3GirOMtH8Luct', '309060086578', '156980859299', 5, 1, '2021-04-05 13:26:12'),
(6, 'f3GirOMtH8Luct', '156980859299', '309060086578', 7, 1, '2021-04-05 13:29:12'),
(7, 'ygwMbs4TGCn3Jb', '309060086578', '156980859299', 1, 1, '2021-04-08 16:24:41'),
(8, 'ygwMbs4TGCn3Jb', '309060086578', '156980859299', 2, 1, '2021-04-08 16:24:43'),
(9, 'ygwMbs4TGCn3Jb', '156980859299', '309060086578', 2, 1, '2021-04-08 16:26:59'),
(10, 'ygwMbs4TGCn3Jb', '156980859299', '309060086578', 4, 1, '2021-04-08 16:40:01'),
(11, 'ygwMbs4TGCn3Jb', '309060086578', '156980859299', 5, 1, '2021-04-08 16:41:05'),
(12, 'ygwMbs4TGCn3Jb', '156980859299', '309060086578', 7, 1, '2021-04-08 16:43:11'),
(13, 'MgtTAUjrd8nNtv', '173733110050', '608879165476', 1, 0, '2021-04-13 05:37:53'),
(14, 'MgtTAUjrd8nNtv', '173733110050', '608879165476', 2, 0, '2021-04-13 05:37:53'),
(15, 'f3GirOMtH8Luct', '156980859299', '309060086578', 5, 1, '2021-04-23 15:34:36'),
(16, '1iGlBywqFqGQWW', '173733110050', '156980859299', 1, 1, '2021-04-25 20:09:50'),
(17, '1iGlBywqFqGQWW', '173733110050', '156980859299', 2, 1, '2021-04-25 20:09:50'),
(18, 'WlJ8du9zhzyqW8', '309060086578', '156980859299', 1, 1, '2021-04-26 18:16:28'),
(19, 'WlJ8du9zhzyqW8', '309060086578', '156980859299', 2, 1, '2021-04-26 18:16:28'),
(20, 'WlJ8du9zhzyqW8', '712294760317', '156980859299', 1, 1, '2021-05-06 15:06:59'),
(21, 'WlJ8du9zhzyqW8', '712294760317', '156980859299', 2, 1, '2021-05-06 15:07:01'),
(22, '1V6uD4iI8tKa04', '309060086578', '156980859299', 1, 1, '2021-05-08 14:16:21'),
(23, '1V6uD4iI8tKa04', '309060086578', '156980859299', 2, 1, '2021-05-08 14:16:22'),
(24, '1V6uD4iI8tKa04', '156980859299', '309060086578', 2, 1, '2021-05-08 14:18:52'),
(25, '1V6uD4iI8tKa04', '156980859299', '309060086578', 2, 1, '2021-05-08 14:19:07'),
(26, 'MzIxp2mbWFvTTd', '309060086578', '156980859299', 1, 1, '2021-05-08 19:03:04'),
(27, 'MzIxp2mbWFvTTd', '712294760317', '156980859299', 2, 1, '2021-05-08 19:03:05'),
(28, 'MzIxp2mbWFvTTd', '156980859299', '712294760317', 2, 1, '2021-05-08 19:04:38'),
(29, 'MzIxp2mbWFvTTd', '712294760317', '156980859299', 2, 1, '2021-05-08 19:07:06'),
(30, 'MzIxp2mbWFvTTd', '118670605130', '156980859299', 1, 1, '2021-05-15 15:01:30'),
(31, 'MzIxp2mbWFvTTd', '712294760317', '156980859299', 2, 1, '2021-05-15 15:01:31'),
(32, 'Up5drnBJ2YlWxk', '309060086578', '156980859299', 1, 0, '2021-05-20 13:16:35'),
(33, 'Up5drnBJ2YlWxk', '712294760317', '156980859299', 2, 0, '2021-05-20 13:16:36'),
(34, 'Up5drnBJ2YlWxk', '156980859299', '712294760317', 2, 1, '2021-05-20 13:19:26'),
(35, 'Up5drnBJ2YlWxk', '712294760317', '156980859299', 2, 0, '2021-05-20 13:35:58'),
(36, 'Up5drnBJ2YlWxk', '309060086578', '156980859299', 1, 0, '2021-05-21 17:16:22'),
(37, 'Up5drnBJ2YlWxk', '712294760317', '156980859299', 2, 0, '2021-05-21 17:16:22');

-- --------------------------------------------------------

--
-- Table structure for table `parent_category`
--

CREATE TABLE `parent_category` (
  `parent_category_id` int(111) NOT NULL,
  `name` varchar(111) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parent_category`
--

INSERT INTO `parent_category` (`parent_category_id`, `name`) VALUES
(1, 'GIS SERVICES'),
(2, 'LAND SERVEY AND MAPPING');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(255) NOT NULL,
  `escrow_id` varchar(300) NOT NULL,
  `projectid` varchar(300) NOT NULL,
  `freelancerid` varchar(300) NOT NULL,
  `clientid` varchar(300) NOT NULL,
  `nid` varchar(300) NOT NULL,
  `client_money` decimal(15,2) NOT NULL,
  `freelancer_money` decimal(15,2) NOT NULL,
  `company_money` decimal(15,2) NOT NULL,
  `complete` tinyint(4) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `escrow_id`, `projectid`, `freelancerid`, `clientid`, `nid`, `client_money`, `freelancer_money`, `company_money`, `complete`, `date_added`) VALUES
(1, '1', 'f3GirOMtH8Luct', '309060086578', '156980859299', '6', '500.00', '350.00', '150.00', 1, '2021-04-05 13:29:12'),
(2, '2', 'ygwMbs4TGCn3Jb', '309060086578', '156980859299', '12', '400000.00', '280000.00', '120000.00', 1, '2021-04-08 16:43:11');

-- --------------------------------------------------------

--
-- Table structure for table `portfolio`
--

CREATE TABLE `portfolio` (
  `id` int(255) NOT NULL,
  `userid` varchar(300) NOT NULL,
  `description` longtext NOT NULL,
  `imagelocation` varchar(300) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `portfolio`
--

INSERT INTO `portfolio` (`id`, `userid`, `description`, `imagelocation`, `date_added`) VALUES
(1, '309060086578', 'Portfolio of Pixel Inc. Ltd in now days', 'UM3Qe1GeANmEEM.jpg', '2021-04-05 13:17:53');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(255) NOT NULL,
  `projectid` varchar(300) NOT NULL,
  `userid` varchar(300) NOT NULL,
  `freelancerid` varchar(300) NOT NULL,
  `title` varchar(300) NOT NULL,
  `slug` mediumtext NOT NULL,
  `budget` decimal(15,2) NOT NULL,
  `category` varchar(300) NOT NULL,
  `skills` mediumtext NOT NULL,
  `description` longtext NOT NULL,
  `closed` int(70) NOT NULL,
  `complete` tinyint(4) NOT NULL,
  `currency` varchar(11) NOT NULL,
  `document` varchar(111) NOT NULL,
  `complete_date` datetime NOT NULL,
  `hired_date` datetime NOT NULL,
  `disputed_date` datetime NOT NULL,
  `date_added` datetime NOT NULL,
  `admin_approved` varchar(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `projectid`, `userid`, `freelancerid`, `title`, `slug`, `budget`, `category`, `skills`, `description`, `closed`, `complete`, `currency`, `document`, `complete_date`, `hired_date`, `disputed_date`, `date_added`, `admin_approved`) VALUES
(1, 'f3GirOMtH8Luct', '156980859299', '309060086578', 'Testing Project', 'testing-project', '1000000.00', 'Topographical and hydrographic maps', 'Sample Skill', '<p>testing description on testing project</p>', 1, 1, '', '', '2021-04-05 13:29:12', '2021-04-05 13:24:03', '0000-00-00 00:00:00', '2021-04-05 12:01:39', '1'),
(2, 'ygwMbs4TGCn3Jb', '156980859299', '309060086578', 'sample title', 'sample-title', '500000.00', 'Street-addressing ', 'Sample Skill', '<p>Description of the project here</p>', 1, 1, '', '', '2021-04-08 16:43:11', '2021-04-08 16:40:03', '0000-00-00 00:00:00', '2021-04-08 16:17:48', '0'),
(3, 'MgtTAUjrd8nNtv', '156980859299', '', 'mapping schools', 'mapping-schools', '300000.00', 'Land use Land Cover (LULC) maps', 'Sample Skill', '<p>We want services<br></p>', 0, 0, '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-04-13 04:44:10', '0'),
(5, '1iGlBywqFqGQWW', '156980859299', '', 'albert test', 'albert-test', '1000.00', 'Router optimization plans - roads, railways, electricity and pipeline', 'Sample Skill', '<p>testing</p>', 0, 0, 'Rwf', 'sample', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-04-20 10:36:26', '0'),
(6, 'DEwBiB6oCXdnHt', '156980859299', '', 'test', 'test', '111.00', 'Physical plans, master plans, and settlement plans', 'Sample Skill', '<p>fsdfsdfsdfsdf</p>', 1, 0, '$$', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-04-20 11:40:36', '0'),
(7, 'D0BaEZSRlKVy0J', '156980859299', '', 'test', 'test', '111.00', 'Physical plans, master plans, and settlement plans', 'Sample Skill', '<p>fsdfsdfsdfsdf</p>', 1, 0, '$$', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-04-20 11:41:13', '0'),
(8, '2lXWeguQ2G1HZM', '156980859299', '', 'test agaibn', 'test-agaibn', '111.00', 'Topographical and hydrographic maps', 'Sample Skill', '<p>test</p>', 1, 0, 'Rwf', 'https://questgis.com/client/download/21', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-04-20 11:46:25', '0'),
(9, 'LSjsk7F0NQlVZ1', '156980859299', '', 'testing project', 'testing-project', '100.00', 'Climate Change Vulnerability maps ', 'Sample Skill', 'testing description', 1, 0, 'frw', 'www.pixel.rw', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-04-22 17:55:37', '0'),
(10, 'pAXW0JlFDoyuYY', '156980859299', '', 'Pixel Testing', 'pixel-testing', '100.00', 'Land and forest degradation maps and community restoration plans.', 'Sample Skill', '<p>testing</p>', 0, 0, 'frw', 'www.pixel.rw', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-04-22 17:56:54', '0'),
(11, 'WlJ8du9zhzyqW8', '156980859299', '', 'jOSEPH tESTING pROJECT', 'joseph-testing-project', '10000000.00', 'Land use Land Cover (LULC) maps', 'Sample Skill', '<p>testing description</p>', 0, 0, 'fRW', 'www.file.com', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-04-23 15:46:06', '0'),
(12, '1V6uD4iI8tKa04', '156980859299', '', 'Final Testing Project', 'final-testing-project', '50000000.00', 'Environment and Natural Resources Management', 'Sample Skill', '<p>testing description for final testing</p>', 0, 0, 'RWF', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-05-08 14:09:44', '0'),
(13, 'qMVbwytIqJHHiW', '156980859299', '', 'teshhssdf', 'teshhssdf', '235345345.00', 'Environment and Natural Resources Management', 'Sample Skill', '<p>statsdgdfgdsfs gfdfgdfgdfg</p>', 0, 0, 'sdt', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-05-08 18:57:33', '0'),
(14, 'MzIxp2mbWFvTTd', '156980859299', '', 'Technology Project', 'technology-project', '1000000.00', 'Environment and Natural Resources Management', 'Sample Skill', '<p>testing this project description</p>', 0, 0, 'frw', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-05-08 19:00:37', '1'),
(15, 'qUNUHuv1jmxQGl', '246459054549', '', 'Stake out', 'stake-out', '100000.00', '59', 'Sample Skill', '<p>ggggg<br></p>', 1, 0, 'RWF', 'CXXX', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-05-09 14:23:04', '0'),
(16, 'Up5drnBJ2YlWxk', '156980859299', '', 'final version ', 'final-version', '1000000.00', 'Environment and Natural Resources Management', 'Sample Skill', '<p>adfsfsdsd sgsdgsdgsdgsd</p>', 0, 0, 'Frw', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-05-20 13:13:06', '0');

-- --------------------------------------------------------

--
-- Table structure for table `proposals`
--

CREATE TABLE `proposals` (
  `id` int(255) NOT NULL,
  `projectid` varchar(300) NOT NULL,
  `freelancerid` varchar(300) NOT NULL,
  `clientid` varchar(300) NOT NULL,
  `nid` varchar(300) NOT NULL,
  `budget` decimal(15,2) NOT NULL,
  `action` tinyint(4) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `proposals`
--

INSERT INTO `proposals` (`id`, `projectid`, `freelancerid`, `clientid`, `nid`, `budget`, `action`, `date_added`) VALUES
(1, 'f3GirOMtH8Luct', '309060086578', '156980859299', '1', '500.00', 2, '2021-04-05 13:13:03'),
(2, 'ygwMbs4TGCn3Jb', '309060086578', '156980859299', '7', '400000.00', 2, '2021-04-08 16:24:42'),
(3, 'MgtTAUjrd8nNtv', '173733110050', '608879165476', '13', '100000.00', 1, '2021-04-13 05:37:53'),
(4, '1iGlBywqFqGQWW', '173733110050', '156980859299', '16', '400000.00', 1, '2021-04-25 20:09:50'),
(5, 'WlJ8du9zhzyqW8', '309060086578', '156980859299', '18', '100000.00', 1, '2021-04-26 18:16:28'),
(6, 'WlJ8du9zhzyqW8', '712294760317', '156980859299', '20', '1000.00', 1, '2021-05-06 15:07:00'),
(7, '1V6uD4iI8tKa04', '309060086578', '156980859299', '22', '40000000.00', 1, '2021-05-08 14:16:22'),
(8, 'MzIxp2mbWFvTTd', '712294760317', '156980859299', '26', '200000.00', 1, '2021-05-08 19:03:05'),
(9, 'MzIxp2mbWFvTTd', '712294760317', '156980859299', '30', '200000.00', 1, '2021-05-15 15:01:30'),
(10, 'Up5drnBJ2YlWxk', '712294760317', '156980859299', '32', '800000.00', 1, '2021-05-20 13:16:35'),
(11, 'Up5drnBJ2YlWxk', '712294760317', '156980859299', '36', '565.00', 1, '2021-05-21 17:16:22');

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `id` int(255) NOT NULL,
  `projectid` varchar(300) NOT NULL,
  `user_sending` varchar(300) NOT NULL,
  `user_receiving` varchar(300) NOT NULL,
  `nid` varchar(300) NOT NULL,
  `rate` int(250) NOT NULL,
  `description` mediumtext NOT NULL,
  `read_status` tinyint(4) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `id` int(255) NOT NULL,
  `userid` varchar(300) NOT NULL,
  `number` varchar(300) NOT NULL,
  `read_status` tinyint(4) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`id`, `userid`, `number`, `read_status`, `date_added`) VALUES
(1, '309060086578', '0788246373', 1, '2021-04-08 17:00:37');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `language` varchar(50) CHARACTER SET utf8 NOT NULL,
  `theme` varchar(50) CHARACTER SET utf8 NOT NULL,
  `sitename` varchar(300) CHARACTER SET utf8 NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 NOT NULL,
  `description` varchar(255) CHARACTER SET utf8 NOT NULL,
  `keywords` varchar(255) CHARACTER SET utf8 NOT NULL,
  `analytics` varchar(200) CHARACTER SET utf8 NOT NULL,
  `timezone` varchar(300) CHARACTER SET utf8 NOT NULL,
  `logo` varchar(300) CHARACTER SET utf8 NOT NULL,
  `favicon` varchar(300) CHARACTER SET utf8 NOT NULL,
  `contact_email` varchar(300) CHARACTER SET utf8 NOT NULL,
  `contact_phone` varchar(300) CHARACTER SET utf8 NOT NULL,
  `contact_location` varchar(300) CHARACTER SET utf8 NOT NULL,
  `facebook` varchar(200) CHARACTER SET utf8 NOT NULL,
  `instagram` varchar(200) CHARACTER SET utf8 NOT NULL,
  `twitter` varchar(200) CHARACTER SET utf8 NOT NULL,
  `smtp_host` varchar(300) CHARACTER SET utf8 NOT NULL,
  `smtp_username` varchar(300) CHARACTER SET utf8 NOT NULL,
  `smtp_password` varchar(300) CHARACTER SET utf8 NOT NULL,
  `smtp_encryption` varchar(300) CHARACTER SET utf8 NOT NULL,
  `smtp_port` varchar(300) CHARACTER SET utf8 NOT NULL,
  `currency` int(50) NOT NULL,
  `paypal_active` tinyint(4) NOT NULL,
  `sandbox` tinyint(4) NOT NULL,
  `paypal_email` varchar(300) CHARACTER SET utf8 NOT NULL,
  `stripe_active` tinyint(4) NOT NULL,
  `stripe_secret_key` varchar(300) CHARACTER SET utf8 NOT NULL,
  `stripe_public_key` varchar(300) CHARACTER SET utf8 NOT NULL,
  `razorpay_active` tinyint(4) NOT NULL,
  `razorpay_key_id` varchar(300) CHARACTER SET utf8 NOT NULL,
  `bank_active` tinyint(4) NOT NULL,
  `bank_description` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `how_client` longtext CHARACTER SET utf8 NOT NULL,
  `how_freelancer` longtext CHARACTER SET utf8 NOT NULL,
  `how_client_image` varchar(200) CHARACTER SET utf8 NOT NULL,
  `how_freelancer_image` varchar(200) CHARACTER SET utf8 NOT NULL,
  `refund_policy` longtext CHARACTER SET utf8 NOT NULL,
  `terms` longtext CHARACTER SET utf8 NOT NULL,
  `privacy_policy` longtext CHARACTER SET utf8 NOT NULL,
  `revenue` int(200) NOT NULL,
  `transaction_fee` decimal(15,2) NOT NULL,
  `pay_freelancers` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `withdrawal_limit` decimal(15,2) NOT NULL,
  `paystack_active` tinyint(4) NOT NULL,
  `paystack_key` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `about_title` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `about_description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `about_company` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `about_image` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `years_of_experience` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `language`, `theme`, `sitename`, `title`, `description`, `keywords`, `analytics`, `timezone`, `logo`, `favicon`, `contact_email`, `contact_phone`, `contact_location`, `facebook`, `instagram`, `twitter`, `smtp_host`, `smtp_username`, `smtp_password`, `smtp_encryption`, `smtp_port`, `currency`, `paypal_active`, `sandbox`, `paypal_email`, `stripe_active`, `stripe_secret_key`, `stripe_public_key`, `razorpay_active`, `razorpay_key_id`, `bank_active`, `bank_description`, `how_client`, `how_freelancer`, `how_client_image`, `how_freelancer_image`, `refund_policy`, `terms`, `privacy_policy`, `revenue`, `transaction_fee`, `pay_freelancers`, `withdrawal_limit`, `paystack_active`, `paystack_key`, `about_title`, `about_description`, `about_company`, `about_image`, `years_of_experience`) VALUES
(1, 'english', 'boxplace', 'Questgis', 'Questgis', 'Questgis', 'Questgis', 'UA-79656468-7', 'Africa/Kigali', '0Iyj1TJChVJbJd.png', 'X9fPc7fH8Mm48J.png', 'equestrwanda@yahoo.com', '+250785186361 | +250785186361', 'BP 2504,KIGALI', 'https://www.facebook.com', 'https://www.instagram.com', 'https://www.twitter.com', 'smtp.gmail.com', 'pixelincltd@gmail.com', 'Security@pixel.rw', 'tls', '587', 42, 1, 1, 'themashabrandbusiness@gmail.com', 1, 'sk_test_IMq9XsThe0AEDUNEdYwwZdxS', 'pk_test_0sPQBhDwhX7x4kn3azVd0Jnn', 1, 'rzp_test_dfBtLvDuaRMdkR', 2, '<p>Payment via account number:<br>Card Number:&nbsp;<br>Card Name: Equest Mapping Ltd<br>Bank Name: Bank name here<br>Swift Code: Swift Code here<br></p>', '<p><b>Posting Projects</b><br></p><p>After registration, you will be \r\nable to login in your account where you can post a project.</p><p><b>Hiring Freelancers<br></b></p><p>After\r\n posting your project, you will receive proposals from interested \r\nfreelancers. You can look at their profiles and even send them messages \r\nfor more discussions.</p><p>After you are satisfied you have found the right Freelancer, go a head and hire him/her.</p><p><b>Adding Funds<br></b></p><p>You\r\n will not be able to hire a Freelancer if your Funds Account is $0.00 on\r\n your dashboard. </p><p>So what you do is go to the Funds section and add some \r\nmoney through either PayPal, Stripe, PayStack or Razorpay.</p><p><b>Escrow<br></b></p><p>Escrow\r\n is where the money will be held until the project is complete. </p><p>When you\r\n hire a Freelancer, the money will not be sent to the Freelancer\'s \r\naccount, instead it will be held by the Wave Company. </p><p><b>Disputes<br></b></p><p>If\r\n at any time you have a problem with the Freelancer, you can start a \r\nDispute in which Wave Company will have a dispute conversations between \r\nyou and the Freelancer.</p><p>The Wave Company will decide if the the money from Escrow should be Returned to the Client or Awarded to the Freelancer.<br></p><p> </p>', '<p><b>Looking for Projects</b><br></p><p>You can look for projects in \r\nwhich you seem fit with your skills. Then post a proposal where you will\r\n get a response from the Client.<br></p><p><b>Invited to Projects<br></b></p><p>At times a Client may invite you to do a project for him/her, you will get a notification concerning the Invite.<br></p><p><b>Building your Portfolio<br></b></p><p>Clients\r\n before they hire anyone, they always check their Portfolio, Work \r\nExperience, Education Experience and even About yourself. So remember to\r\n build your Portfolio.<br></p><p><b>Escrow<br></b></p><p>Escrow\r\n is where the money will be held until the project is complete. </p><p>When you get hired , the money will not be sent to the your \r\naccount, instead it will be held by the Wave Company. </p><p><b>Disputes<br></b></p><p>If\r\n at any time you have a problem with the Client, you can start a \r\nDispute in which Wave Company will have a dispute conversations between \r\nyou and the Client.</p><p>The Wave Company will decide if the the money from Escrow should be Returned to the Client or Awarded to the Freelancer.<br></p>', 'A1xp2l2j0JdqgI.jpg', 'aTrW7aAurd9xBY.jpg', '<p>Refund policy will be added here</p>', '<p>Terms and Condition will be added here</p>', '<p>Privacy Policy will be added here</p>', 25, '1.00', '7', '20.00', 1, 'pk_test_f70f1e66c2dfd5385acf7ef2ef30361e6427ebd5', 'Who We Are', '<div class=\"o-flex-container__item\">\r\n                        <p>Questgis is a network of trusted GIS and land survey professionals in Africa dedicated to providing matchless solutions in resource survey and mapping across the continent.Questgis we will help you develop affordable and timely GIS and land surely solutions for your projects, whether individual or corporate.We are revolutionizing the conventional way of acquiring GIS and mapping expertise for your projects. Searching for trusted and experienced mapping professional has been made easier. Its now at the comfort of your home or office. Through our network, we will get closer to your project areas and provide timely, quality and ground-truithed mapping services. We understand the hustle of finding mapping services whether for short short-term or long terms assignments. We professionally take up this responsibility to ensure you get things done by experts whose qualifications, experiences, background, and competencies are well vetted.</p>\r\n\r\n                        \r\n                    </div>', 'Quest Mapping Ltd', '21.04.13.10.48-1618303685.982-25485602.png', 0);

-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE `skills` (
  `id` int(255) NOT NULL,
  `name` varchar(300) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`id`, `name`) VALUES
(1, 'Sample Skill');

-- --------------------------------------------------------

--
-- Table structure for table `sms`
--

CREATE TABLE `sms` (
  `id` int(11) NOT NULL,
  `phone` varchar(111) NOT NULL,
  `msg` varchar(111) NOT NULL,
  `status` varchar(111) NOT NULL,
  `date_added` varchar(111) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sms`
--

INSERT INTO `sms` (`id`, `phone`, `msg`, `status`, `date_added`) VALUES
(2, '', '', '{\"code\":\"ok\",\"message\":\"Successfully Sent\",\"messageId\":\"Success|250787967023|0a43ed21-109d-400c-ad45-be887aa60c', '26/04/2021 12:55:10'),
(3, '', '', '{\"code\":\"ok\",\"message\":\"Successfully Sent\",\"messageId\":\"Success|250787605005|e68caeda-f1ee-4e29-9201-b6ae869920', '26/04/2021 12:56:28'),
(4, '', '', '{\"code\":\"ok\",\"message\":\"Successfully Sent\",\"messageId\":\"Success|250787967023|95edeeda-2397-482b-ada4-4b17770b3d', '26/04/2021 01:02:47'),
(5, '250787967023', '', '{\"code\":\"ok\",\"message\":\"Successfully Sent\",\"messageId\":\"Success|250788246373|1125ce8a-dda7-45bd-8f6e-6202a002bd', '26/04/2021 01:57:33'),
(6, '250787967023', '', '{\"code\":\"ok\",\"message\":\"Successfully Sent\",\"messageId\":\"Success|250788246373|2adb666c-fafc-44a3-af82-dd8d7740b6', '26/04/2021 02:00:04'),
(7, '250788246373', '', '{\"code\":\"ok\",\"message\":\"Successfully Sent\",\"messageId\":\"Success|250788246373|78189da8-c0b7-4e4f-94ca-729b7c902d', '26/04/2021 02:21:25'),
(8, '250788246373', '', '{\"code\":\"ok\",\"message\":\"Successfully Sent\",\"messageId\":\"Success|250788246373|34f0ace1-7db3-491e-bfee-6f873d5da7', '08/05/2021 09:51:28'),
(9, '250785186361', '', '{\"code\":\"ok\",\"message\":\"Successfully Sent\",\"messageId\":\"Success|250785186361|a91004f3-58ac-46ca-8df3-0ae7e99fae', '08/05/2021 09:53:52');

-- --------------------------------------------------------

--
-- Table structure for table `sub_category`
--

CREATE TABLE `sub_category` (
  `id` int(111) NOT NULL,
  `sub_cat_name` varchar(111) NOT NULL,
  `cat_id` int(111) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE `team` (
  `id` int(255) NOT NULL,
  `name` varchar(300) NOT NULL,
  `title` varchar(300) NOT NULL,
  `facebook` varchar(300) NOT NULL,
  `twitter` varchar(300) NOT NULL,
  `instagram` varchar(300) NOT NULL,
  `imagelocation` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `team`
--

INSERT INTO `team` (`id`, `name`, `title`, `facebook`, `twitter`, `instagram`, `imagelocation`) VALUES
(1, 'Name Here', 'Team leader', 'www.facaebook.com', 'www.twitter.com', 'www.instagram.com', '21.04.13.11.21-1618305701.7781-53810142.jpeg'),
(2, 'Name Here', 'Deputy team leader ', 'www.facebook.com', 'www.twitter.com', 'www.instagram.com', '21.04.13.11.22-1618305773.7148-68584432.jpeg'),
(3, 'Name Here', 'Technical manager ', 'www.facebook.com', 'www.twitter.com', 'www.instagram.com', '21.04.13.11.23-1618305823.9005-36954302.jpeg'),
(4, 'Name Here', 'Administration manager ', 'www.facebook.com', 'www.twitter.com', 'www.instagram.com', '21.04.13.11.24-1618305870.9629-61530768.jpeg'),
(5, 'Name Here', 'Quality assurance manager ', 'www.facebook.com', 'www.twitter.com', 'www.instagram.com', '21.04.13.11.25-1618305916.1098-3129851.jpeg'),
(6, 'Name here', 'IT developer', 'www.facebook.com', 'www.twitter.com', 'www.instagram.com', '21.04.13.11.26-1618305971.552-98541374.jpeg'),
(7, 'Name Here', 'Public relations manager ', 'www.facebook.com', 'www.twitter.com', 'www.instagram.com', '21.04.13.11.27-1618306023.152-10190503.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `theme`
--

CREATE TABLE `theme` (
  `id` int(255) NOT NULL,
  `name` varchar(300) NOT NULL,
  `title` varchar(300) NOT NULL,
  `sub_title` varchar(300) NOT NULL,
  `project_search` varchar(300) NOT NULL,
  `freelancer_search` varchar(300) NOT NULL,
  `categories_title` varchar(300) NOT NULL,
  `portfolio_title` varchar(300) NOT NULL,
  `how_it_works_title` varchar(300) NOT NULL,
  `customers_title` varchar(300) NOT NULL,
  `join_us_title` varchar(300) NOT NULL,
  `bg_image_one` varchar(300) NOT NULL,
  `bg_image_two` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `theme`
--

INSERT INTO `theme` (`id`, `name`, `title`, `sub_title`, `project_search`, `freelancer_search`, `categories_title`, `portfolio_title`, `how_it_works_title`, `customers_title`, `join_us_title`, `bg_image_one`, `bg_image_two`) VALUES
(1, 'boxplace', 'Searching for GIS and Land Survey Solutions anywhere in Africa?', 'Questgis provides excellent GIS and land survey services anywhere around the continent.  ', 'What Project are you looking for?', 'We are a trusted network of GIS and Land Survey professionals in the continent.', 'Popular Categories', 'Land use Land Cover (LULC) maps', 'How It Works', 'Few Words from our Valuable Customers', 'Millions of small businesses use Questgis to turn their ideas into reality.', '7lM9xvc6ZVotvj.jpg', 'bUnztYS3Hm5810.jpg'),
(2, 'boxsale', 'Build an Outstanding Digital Marketplace', '', '', '', '', '', '', '', '', 'ZyoQE4Vlbf4Qee.jpg', 'Mft0pamEteN23T.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(255) NOT NULL,
  `userid` varchar(300) NOT NULL,
  `password` varchar(64) NOT NULL,
  `name` varchar(300) NOT NULL,
  `slug` varchar(300) NOT NULL,
  `email` text NOT NULL,
  `project_type` varchar(111) NOT NULL DEFAULT '1',
  `credit_account` decimal(15,2) NOT NULL,
  `paypal_email` varchar(300) NOT NULL,
  `imagelocation` text NOT NULL,
  `bg_imagelocation` text NOT NULL,
  `tokencode` text NOT NULL,
  `joined` datetime NOT NULL,
  `user_type` int(11) NOT NULL,
  `registercode` varchar(300) NOT NULL,
  `verified` tinyint(4) NOT NULL,
  `email_verified` tinyint(4) NOT NULL,
  `title` varchar(300) NOT NULL,
  `website` varchar(300) NOT NULL,
  `country` varchar(300) NOT NULL,
  `categories` mediumtext NOT NULL,
  `skills` mediumtext NOT NULL,
  `about` longtext NOT NULL,
  `email_settings` tinyint(4) NOT NULL,
  `jobs_notifications` tinyint(4) NOT NULL,
  `status` int(111) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `userid`, `password`, `name`, `slug`, `email`, `project_type`, `credit_account`, `paypal_email`, `imagelocation`, `bg_imagelocation`, `tokencode`, `joined`, `user_type`, `registercode`, `verified`, `email_verified`, `title`, `website`, `country`, `categories`, `skills`, `about`, `email_settings`, `jobs_notifications`, `status`) VALUES
(1, '156980859299', '$2y$10$KQJtOEd/NW3YA4UB8hcGBOcS8RYYJW0t.mHAjlwMzc8jK.e.Ax0Xu', 'Munyawera Fils', 'munyawera-fils', 'munyawerafils@pixel.rw', '1', '1000.00', '', 'default.png', 'https://www.irishrsa.ie/wp-content/uploads/2017/03/default-avatar.png', '', '2021-04-05 11:52:03', 2, '', 1, 0, '0788246373', 'www.pixel.rw', 'rwanda', '', '', '', 0, 0, 0),
(2, '309060086578', '$2y$10$C/GoveCSMbCdzwqc/SKnLetmFTU98ctxfJI92Xpn5a..Lpwjucray', 'Pixel Inc. ltd', 'pixel-inc-ltd', 'serge@pixel.rw', '1', '280150.00', 'munfils96@gmail.com', '6pcG2vH48Jha6B.jpg', 'https://www.irishrsa.ie/wp-content/uploads/2017/03/default-avatar.png', '', '2021-04-05 12:55:29', 1, '', 1, 0, '', '', '', '', '', '', 0, 0, 1),
(3, '179710539010', '$2y$10$Recw9YOqjdwR5l0UTz2DA.xoK.7GFOj0h4dVQ7129wutrh8tXIAYy', 'AZByeqLUVPMScsJi', 'azbyeqluvpmscsji', 'sappiesedcg@gmail.com', '1', '0.00', '', 'default.png', 'https://www.irishrsa.ie/wp-content/uploads/2017/03/default-avatar.png', '', '2021-04-07 05:39:25', 2, '', 0, 0, '', '', '', '', '', '', 0, 0, 0),
(6, '120408001918', '$2y$10$.b4CM5yu.xLE5C84mI1JCe1bEXAXTLEFEi2TyxLa7Fz1WpTdQ.FEm', 'pxQicOJjeVzf', 'pxqicojjevzf', 'colotandwk@gmail.com', '1', '0.00', '', 'default.png', 'https://www.irishrsa.ie/wp-content/uploads/2017/03/default-avatar.png', '', '2021-05-03 11:38:44', 1, '', 0, 0, '', '', '', '', '', '', 0, 0, 0),
(7, '712294760317', '$2y$10$AIDPKnLjOxtOPB8wMPukn.NLQ73tQApfklZi1MBiJTFMvwRXORS..', 'admin', 'admin', 'admin@questgis.com', '1', '0.00', '', 'default.png', 'https://www.irishrsa.ie/wp-content/uploads/2017/03/default-avatar.png', '', '2021-05-05 11:57:18', 1, '', 0, 0, '', '', '', '', '', '', 0, 0, 0),
(8, '151528589800', '$2y$10$DB6Xtjy7zNkg7/AvARvDnO1sUcjUJNxnyNx5Po7OZRsLe4OaAN71u', 'test', 'test', 'admin1@questgis.com', '36', '0.00', '', 'default.png', 'https://www.irishrsa.ie/wp-content/uploads/2017/03/default-avatar.png', '', '2021-05-08 19:56:08', 1, '', 0, 0, '', '', '', '', '', '', 0, 0, 0),
(9, '263411373215', '$2y$10$YGisJNDvKf0eU/USJDdbnOwRGoVcB6OCihvXyUkvTe1lufz4sUUBi', 'felix', 'felix', 'felix@pixel.rw', '43', '0.00', '', 'default.png', 'https://www.irishrsa.ie/wp-content/uploads/2017/03/default-avatar.png', '', '2021-05-08 20:00:04', 1, '', 0, 0, '', '', '', '', '', '', 0, 0, 0),
(10, '699895250111', '$2y$10$L.jUgskFh9GB0bDTvnkjquIU25cFRVF2XrZzk43zPZAeHFVTy.WW.', 'fils@pixel.rw', 'fils-pixel-rw', 'fils@pixel.rw', '44', '0.00', '', 'default.png', 'https://www.irishrsa.ie/wp-content/uploads/2017/03/default-avatar.png', '', '2021-05-08 20:03:57', 1, '', 0, 0, '', '', '', '', '', '', 0, 0, 0),
(11, '505276499242', '$2y$10$V8ktjb3p7eQ1/pi1G9cd7emp92G8fWkTLBD.uxzkeT92BXg2Jp8eC', 'Test ', 'test', 'test@gmail.com', '46', '0.00', '', 'default.png', 'https://www.irishrsa.ie/wp-content/uploads/2017/03/default-avatar.png', '', '2021-05-08 20:05:32', 1, '', 0, 0, '', '', '', '', '', '', 0, 0, 0),
(12, '175102083731', '$2y$10$PDhkEZUBwygoAsZ1c/xfZullFSGkAeKh1o95v88/gjrpkCRaQIJkS', 'Pixel', 'pixel', 'Pixel@gmail.com', '39', '0.00', '', 'default.png', 'https://www.irishrsa.ie/wp-content/uploads/2017/03/default-avatar.png', '', '2021-05-08 20:07:22', 1, '', 0, 0, '', '', '', '', '', '', 0, 0, 0),
(13, '181012054867', '$2y$10$jHAII/yCEylbg8WBCfn1VucQf0jgbh2igY7dM53rEvgy26TR15PNS', 'trial', 'trial', 'trial@pixel.rw', '36', '0.00', '', 'default.png', 'https://www.irishrsa.ie/wp-content/uploads/2017/03/default-avatar.png', '', '2021-05-08 20:09:43', 1, '', 0, 0, '', '', '', '', '', '', 0, 0, 0),
(14, '517078557732', '$2y$10$EMb7cEOl4B5tfCDTbkKkqevfG4n51W7.wcsuD01Y4Yr6r05U0XkNi', 'secondtest', 'secondtest', 'second@pixel.rw', '35', '0.00', '', 'default.png', 'https://www.irishrsa.ie/wp-content/uploads/2017/03/default-avatar.png', '', '2021-05-08 20:41:22', 1, '', 0, 0, '', '', '', '', '', '', 0, 0, 0),
(15, '616358737767', '$2y$10$1zzokJQREEtazQ8IAAwHSu8cvIm.VzQL3Ne/iS8ybPlYDo.4Vv3tK', 'testing', 'testing', 'testagain@pixel.rw', '57', '0.00', '', 'default.png', 'https://www.irishrsa.ie/wp-content/uploads/2017/03/default-avatar.png', '', '2021-05-09 12:36:15', 1, '', 0, 0, '', '', '', '', '', '', 0, 0, 0),
(16, '137506505235', '$2y$10$54PHYPrG2p1lX70uU6ea4.oIRvauxe1xSClNhQGwAqQCF0D8TtZbm', 'munfisl', 'munfisl', 'munfils99086@gmail.com', '42', '0.00', '', 'default.png', 'https://www.irishrsa.ie/wp-content/uploads/2017/03/default-avatar.png', '', '2021-05-09 12:46:42', 1, '', 0, 0, '', '', '', '', '', '', 0, 0, 0),
(17, '319826684826', '$2y$10$JiCB11PGPq0V8lprb8ReeOrdoePDmg3kakFZlWdOJfxh/u/DUMcC.', 'Joseph N', 'joseph-n', 'njirujov78c@gmail.com', '47', '0.00', '', 'default.png', 'https://www.irishrsa.ie/wp-content/uploads/2017/03/default-avatar.png', '', '2021-05-09 13:23:33', 1, '', 0, 0, '', '', '', '', '', '', 0, 0, 0),
(18, '246459054549', '$2y$10$WU.Koca0/4z2y1GDEXNdtujpc21iNR6qU4OX91xFTmYaNCr7ou9iu', 'Joseph Njiru', 'joseph-njiru', 'njirujo90978966vc@yahoo.com', '', '0.00', '', 'default.png', 'https://www.irishrsa.ie/wp-content/uploads/2017/03/default-avatar.png', '', '2021-05-09 14:13:12', 2, '', 0, 0, '', '', '', '', '', '', 0, 0, 0),
(19, '294435541100', '$2y$10$9zfWP7ZOQTb3QAGr4RjG4.GQDaQK89CEnJYOkomUVmFP..sjNIJVW', 'Munyawera Fils', 'munyawera-fils', 'munfils99906@outlook.com', '', '0.00', 'munfils96@outlook.com', 'default.png', 'https://www.irishrsa.ie/wp-content/uploads/2017/03/default-avatar.png', '', '2021-05-11 19:43:15', 1, '', 0, 0, '07882463737', '', 'Ghana', 'Engineering planning,Smart agriculture,Banking ,Health care ,', '', '', 0, 0, 0),
(20, '122684576683', '$2y$10$1ukw57WePzGWWtzwl5VB7ej.LI23CAtm8S4HEJERve6kfGJldBV6W', 'Munyawera Fils', 'munyawera-fils', 'munfils6757696@outlook.com', '', '0.00', 'munfils96@outlook.com', 'default.png', 'https://www.irishrsa.ie/wp-content/uploads/2017/03/default-avatar.png', '', '2021-05-11 19:46:44', 1, '', 0, 0, '0788246373', '', 'Rwanda', 'Topographic survey,Mining survey,Hydrographic and bathymetry,Geodetic survey and GNSS,,', '', '', 0, 0, 0),
(21, '323866226925', '$2y$10$Kctjs9L4TvPhh1esu0/QhODWj.sBnL3.4W3aHV8zz52KCkx8yeOZC', 'Joseph Njue ', 'joseph-njue', 'njirujovc@gmail.com', '', '0.00', 'njirujovc@gmail.com', 'default.png', 'https://www.irishrsa.ie/wp-content/uploads/2017/03/default-avatar.png', '', '2021-05-11 19:55:53', 2, '', 0, 0, '', '', '', '', '', '', 0, 0, 0),
(23, '118670605130', '$2y$10$PHRBkN4yyPkqufNkN6GPKePo8K/iR99EHezA6ORnGLY6CjELx8y9G', 'Joseph Njiru', 'joseph-njiru', 'equestrwanda@yahoo.com', '', '0.00', 'equestrwanda@yahoo.com', 'default.png', 'https://www.irishrsa.ie/wp-content/uploads/2017/03/default-avatar.png', '', '2021-05-15 14:57:49', 1, '', 1, 0, '+250785186361', '', 'Rwanda', 'Environment and Natural Resources Management,Engineering planning,Smart agriculture,Humanitarian operations and response,Disaster management ,Urban and Rural Planning ,Land Information Management,Population and census,', '', '', 0, 0, 0),
(24, '180677041531', '$2y$10$HMt/azN7ZlvsfMkkl535KOCkqQsezn.ZdS1/iV7UIl59De2aj1.jO', 'Munyawera  Fils', 'munyawera-fils', 'munfils96@outlook.com', '', '0.00', 'munfils96@outlook.com', 'default.png', 'https://www.irishrsa.ie/wp-content/uploads/2017/03/default-avatar.png', '', '2021-05-17 18:28:32', 1, '', 0, 0, '0788246373', '', 'Cyprus', 'Engineering planning,Smart agriculture,Humanitarian operations and response,', '', '', 0, 0, 0),
(25, '295074542901', '$2y$10$PVru32LYoUrwieuPd55pUuPMPnYTkJ4heIXo5P9BdL5a7qzY88oay', 'mun fils', 'mun-fils', 'munfils95@outlook.com', '', '0.00', 'munfils95@outlook.com', 'default.png', 'https://www.irishrsa.ie/wp-content/uploads/2017/03/default-avatar.png', '', '2021-05-18 19:58:52', 1, '', 0, 0, '35646', '', 'Armenia', 'Topographic survey,Mining survey,,', '', '', 0, 0, 0),
(26, '299585975855', '$2y$10$Ha2QC.La.wCjKDPEeyUize4wNtQMVDktcC4mjsHUsDVHNZ0tO0aZe', 'fils yes', 'fils-yes', 'munfils963@outlook.com', '', '0.00', 'munfils963@outlook.com', 'default.png', 'https://www.irishrsa.ie/wp-content/uploads/2017/03/default-avatar.png', '', '2021-05-18 22:48:28', 1, '', 0, 0, '2345678', '', 'Aruba', 'Disaster management ,Urban and Rural Planning ,', '', '', 0, 0, 0),
(27, '684508876533', '$2y$10$N4QVQVSx7zKy6.XNshQhYe2z8vsOwXjYBNKZEJavmZXkiL8AP7qaO', 'tes ste', 'tes-ste', 'admin@pixel.rwr', '', '0.00', 'admin@pixel.rwr', 'default.png', 'https://www.irishrsa.ie/wp-content/uploads/2017/03/default-avatar.png', '', '2021-05-19 15:47:42', 1, '', 0, 0, '324423423', '', 'Aruba', 'Engineering planning,Smart agriculture,Humanitarian operations and response,', '', '', 0, 0, 0),
(28, '264239048161', '$2y$10$/OLiLfnZrfbw.uE0JaLm4e7r2vtfPZq7pFEOm1HHRr1LJpWFQthX6', 'bJgyarILTtZD VEQGdpiI', 'bjgyarilttzd-veqgdpii', 'extrumatesv@gmail.com', '', '0.00', 'extrumatesv@gmail.com', 'default.png', 'https://www.irishrsa.ie/wp-content/uploads/2017/03/default-avatar.png', '', '2021-05-20 16:21:31', 1, '', 0, 0, '2162033767', '', 'Zimbabwe', 'Crime and security ,', '', '', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users_session`
--

CREATE TABLE `users_session` (
  `id` int(11) NOT NULL,
  `user_id` varchar(300) NOT NULL,
  `hash` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `withdrawals`
--

CREATE TABLE `withdrawals` (
  `id` int(255) NOT NULL,
  `code` varchar(300) NOT NULL,
  `freelancerid` varchar(300) NOT NULL,
  `paypal_email` varchar(300) NOT NULL,
  `type` varchar(300) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `transaction_fee` decimal(15,2) NOT NULL,
  `freelancer_receive` decimal(15,2) NOT NULL,
  `action` tinyint(4) NOT NULL,
  `read_status` tinyint(4) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_to_be_paid` datetime NOT NULL,
  `date_paid` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `withdrawals`
--

INSERT INTO `withdrawals` (`id`, `code`, `freelancerid`, `paypal_email`, `type`, `amount`, `transaction_fee`, `freelancer_receive`, `action`, `read_status`, `date_added`, `date_to_be_paid`, `date_paid`) VALUES
(1, 'oBRQoNQs2970PX', '309060086578', 'munfils96@gmail.com', 'PayPal', '200.00', '2.50', '197.50', 2, 1, '2021-04-23 12:23:46', '2021-04-30 12:23:46', '2021-04-23 12:25:03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about_info`
--
ALTER TABLE `about_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category_gis`
--
ALTER TABLE `category_gis`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conversation`
--
ALTER TABLE `conversation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conversation_reply`
--
ALTER TABLE `conversation_reply`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `currency`
--
ALTER TABLE `currency`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dispute_conversation`
--
ALTER TABLE `dispute_conversation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dispute_conversation_reply`
--
ALTER TABLE `dispute_conversation_reply`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `escrow`
--
ALTER TABLE `escrow`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faq`
--
ALTER TABLE `faq`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `funds`
--
ALTER TABLE `funds`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `how_it_works`
--
ALTER TABLE `how_it_works`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invite`
--
ALTER TABLE `invite`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parent_category`
--
ALTER TABLE `parent_category`
  ADD PRIMARY KEY (`parent_category_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `portfolio`
--
ALTER TABLE `portfolio`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `proposals`
--
ALTER TABLE `proposals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skills`
--
ALTER TABLE `skills`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sms`
--
ALTER TABLE `sms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sub_category`
--
ALTER TABLE `sub_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `theme`
--
ALTER TABLE `theme`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_session`
--
ALTER TABLE `users_session`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `withdrawals`
--
ALTER TABLE `withdrawals`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about_info`
--
ALTER TABLE `about_info`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `category_gis`
--
ALTER TABLE `category_gis`
  MODIFY `id` int(111) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `conversation`
--
ALTER TABLE `conversation`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `conversation_reply`
--
ALTER TABLE `conversation_reply`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `currency`
--
ALTER TABLE `currency`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dispute_conversation`
--
ALTER TABLE `dispute_conversation`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dispute_conversation_reply`
--
ALTER TABLE `dispute_conversation_reply`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `escrow`
--
ALTER TABLE `escrow`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `faq`
--
ALTER TABLE `faq`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `funds`
--
ALTER TABLE `funds`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=149;

--
-- AUTO_INCREMENT for table `how_it_works`
--
ALTER TABLE `how_it_works`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `invite`
--
ALTER TABLE `invite`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `parent_category`
--
ALTER TABLE `parent_category`
  MODIFY `parent_category_id` int(111) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `portfolio`
--
ALTER TABLE `portfolio`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `proposals`
--
ALTER TABLE `proposals`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `ratings`
--
ALTER TABLE `ratings`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `skills`
--
ALTER TABLE `skills`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sms`
--
ALTER TABLE `sms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `sub_category`
--
ALTER TABLE `sub_category`
  MODIFY `id` int(111) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `team`
--
ALTER TABLE `team`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `theme`
--
ALTER TABLE `theme`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `users_session`
--
ALTER TABLE `users_session`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `withdrawals`
--
ALTER TABLE `withdrawals`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
