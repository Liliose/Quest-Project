<?php
$reply=$_POST['message'];
$user_sending=$_POST['sender_id'];
$projectid="f3GirOMtH8Luct";//$_POST['projectid'];
$cid=$_POST['cid'];
$nid=date("is");
$conn = new mysqli("localhost","root","","questadmin");
$query="INSERT INTO `conversation_reply` (`id`, `cid`, `projectid`, `nid`, `user_sending`, `reply`, `read_status`, `date_added`, `admin_verified`) VALUES ('', '$cid', '$projectid', '$nid', '$user_sending', '$reply', '0', '2021-05-21 17:16:23', '0')";

$save=$conn->query($query);

?>