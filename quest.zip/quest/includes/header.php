<?php  /*include "session.php"; */
include "class/connection.php";
$myid="156980859299";
function get_message_no($user_id){
include "class/connection.php";
$select="SELECT  count(id) as no FROM message where statusz='0' ";
$data=$conn->query($select);
if ($data!=NULL) {
  $row=$data->fetch_assoc();

  return $row['no'];
}
else
{
  return "0";
}

}
?>
<?php include "class/useraction_class.php"; ?>
<?php include "class/bundle.php"; ?>
<!DOCTYPE html>
 <html lang="zxx">

 <head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
     <!-- Required meta tags -->
     <meta charset="utf-8" />
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
     <title>Management Admin </title>

     <link rel="icon" href="img/mini_logo.png" type="image/png" />
     <!-- Bootstrap CSS -->
     <link rel="stylesheet" href="css/bootstrap.min.css" />
     <!-- themefy CSS -->
     <link rel="stylesheet" href="vendors/themefy_icon/themify-icons.css" />
     <!-- select2 CSS -->
     <link rel="stylesheet" href="vendors/niceselect/css/nice-select.css" />
     <!-- owl carousel CSS -->
     <link rel="stylesheet" href="vendors/owl_carousel/css/owl.carousel.css" />
     <!-- gijgo css -->
     <link rel="stylesheet" href="vendors/gijgo/gijgo.min.css" />
     <!-- font awesome CSS -->
     <link rel="stylesheet" href="vendors/font_awesome/css/all.min.css" />
     <link rel="stylesheet" href="vendors/tagsinput/tagsinput.css" />

     <!-- date picker -->
      <link rel="stylesheet" href="vendors/datepicker/date-picker.css" />

      <link rel="stylesheet" href="vendors/vectormap-home/vectormap-2.0.2.css" />
     
      <!-- scrollabe  -->
      <link rel="stylesheet" href="vendors/scroll/scrollable.css" />
     <!-- datatable CSS -->
     <link rel="stylesheet" href="vendors/datatable/css/jquery.dataTables.min.css" />
     <link rel="stylesheet" href="vendors/datatable/css/responsive.dataTables.min.css" />
     <link rel="stylesheet" href="vendors/datatable/css/buttons.dataTables.min.css" />
     <!-- text editor css -->
     <link rel="stylesheet" href="vendors/text_editor/summernote-bs4.css" />
     <!-- morris css -->
     <link rel="stylesheet" href="vendors/morris/morris.css" />
     <!-- metarial icon css -->
     <link rel="stylesheet" href="vendors/material_icon/material-icons.css" />

     <!-- menu css  -->
     <link rel="stylesheet" href="css/metisMenu.css" />
     <!-- style CSS -->
     <link rel="stylesheet" href="css/style.css" />
     <link rel="stylesheet" href="css/colors/default.css" id="colorSkinCSS" />
 </head>