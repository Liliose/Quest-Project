
            <!-- HEADER DESKTOP-->
            <header class="header-desktop">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <form class="form-header" action="" method="POST">
                                <input class="au-input au-input--xl" type="text" name="search" placeholder="Search for datas &amp; reports..." />
                                <button class="au-btn--submit" type="submit">
                                    <i class="zmdi zmdi-search"></i>
                                </button>
                            </form>
                            <div class="header-button">
                                <div class="noti-wrap">
                                    <div class="noti__item js-item-menu">
                                        <i class="zmdi zmdi-comment-more"></i>
                                        <span class="quantity"><?php echo get_message_no($user_id); ?></span>
                                        <div class="mess-dropdown js-dropdown">
                                            <div class="mess__title">
                                                <p>You have <?php echo $no=get_message_no($user_id); ?> New message(s)</p>
                                            </div>
                                      
                                              
                                              <?php include "class/connection.php";
                                                  
                                                    $select_message="SELECT * FROM message where sender_id='$user_id'  and status='0' limit 5";
                                                    $data_message=$conn->query($select_message);

                                                    if ($data_message->num_rows > 0) {
                                                while ($row_message=$data_message->fetch_assoc()) {
                                                    ?><a href="javascript:void(0)" onClick="updateId('<?php echo $row_message['id']; ?>')" >
                                                <div class="mess__item" id="<?php echo $row_message['id']; ?>" >
                                                <div class="image img-cir img-40">
                                                <img src="images/icon/avatar-06.jpg"  />
                                                <input type="hidden" name="id" id="input_val" value="<?php echo $row_message['id']; ?>">
                                                </div>
                                                <div class="content">
                                                <h6>New From GDG energy System.</h6>
                                                <p><?php echo $row_message['message']; ?></p>
                                                <span class="time"><?php echo $row_message['date_added']; ?></span>
                                                </div>
                                                </div></a>
                                                    <?php
                                                }
                                                    }
                                                  

                                                        if($no > 0){
                                                ?>
                                            <div class="mess__footer">
                                                <a href="#">View all messages</a>
                                            </div>
                                            <?php
                                                        }
                                                        else
                                                        {
                                                ?>
                                                <div class="mess__footer">
                                                <a href="#">No messages yet</a>
                                            </div>
                                            <?php
                                                        }
                                               ?>
                                        
                                        
                                        </div>
                                    </div>
                                    
                                                                    </div>
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                            <img src="images/icon/avatar-01.jpg" alt="<?php echo $_SESSION['username']; ?>" />
                                        </div>
                                        <div class="content">
                                            <a class="js-acc-btn" href="#"><?php echo $_SESSION['username']; ?></a>
                                        </div>
                                        <div class="account-dropdown js-dropdown">
                                            <div class="info clearfix">
                                                <div class="image">
                                                    <a href="#">
                                                        <img src="images/icon/avatar-01.jpg" alt="John Doe" />
                                                    </a>
                                                </div>
                                                <div class="content">
                                                    <h5 class="name">
                                                        <a href="#"><?php echo $_SESSION['username']; ?></a>
                                                    </h5>
                                                    <span class="email"><?php echo $_SESSION['email']; ?></span>
                                                </div>
                                            </div>
                                         
                                            <div class="account-dropdown__footer">
                                                <a href="logout.php">
                                                    <i class="zmdi zmdi-power"></i>Logout</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <script>
function updateId(id)
{
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) 
        {
            document.getElementById(xmlhttp.responseText).style.display="none";
        }
    };
    xmlhttp.open("GET", "update_message.php?id=" +id, true);
    xmlhttp.send();
}
</script>