<?php 
$access=$_SESSION['access'];
if ($access==="agent") {
?>

 <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="#">
                    <img src="images/icon/logo.png"  />
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                                <li>
                                    <a href="manage_customer.php"> <i class="fas fa-warehouse"></i> Manage Customers </a>
                                </li>
                                <li>
                                    <a href="customers.php"> <i class="fas fa-warehouse"></i> Record Customers </a>
                                </li>
                                <li>
                                    <a href="assign_kits_installer.php"> <i class="fas fa-user"></i>Assign Kits to installers </a>
                                </li>
                                <li>
                                    <a href="client_form.php"> <i class="fas fa-user"></i>After installation </a>
                                </li>
                                <li>
                                    <a href="complete_installation.php"> <i class="fas fa-gear"></i> Complete Inst.. </a>
                                </li> 
                                

                              
                    </ul>
                </nav>
            </div>
        </aside>
<?php
}
if ($access==="admin") {
?>

 <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="#">
                    <img src="images/icon/logo.png"  />
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">

  <li>
                                    <a href="import/index.php"> <i class="fas fa-warehouse"></i> Import Customers </a>
                                </li>

                         
                                  <li>
                                    <a href="sent_customers.php"> <i class="fas fa-warehouse"></i>Sent Customer </a>
                                </li>

                                  <li>
                                    <a href="manage_customer.php"> <i class="fas fa-warehouse"></i> All Customers </a>
                                </li>
                                 <li>
                                    <a href="customers.php"> <i class="fas fa-warehouse"></i> Record New Customers </a>
                                </li>
                
                                 <li>
                                    <a href="assign_kits_installer.php"> <i class="fas fa-user"></i>Kits to installers </a>
                                </li>
                                <li>
                                    <a href="payment_details.php"> <i class="fas fa-user"></i>Customer Payments</a>
                                </li>

                                <li>
                                    <a href="complete_installation.php"> <i class="fas fa-gear"></i> Complete Installation </a>
                                </li>
                                 <li>
                                    <a href="main_Stock.php"> <i class="fas fa-warehouse"></i>Record New Kits </a>
                                </li>
                                  <li>
                                    <a href="manage_kit.php"> <i class="fas fa-warehouse"></i>Manage New Kits </a>
                                </li>

                                    <li>
                                    <a href="manage_kit.php"> <i class="fas fa-warehouse"></i>Manage New Kits </a>
                                </li>



                                
                                <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-gear"></i>Settings</a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list">
                                    <li>
                                    <a href="province.php"> <i class="fas fa-map"></i> Province </a>
                                </li>
                              <li>
                                    <a href="district.php"> <i class="fas fa-map"></i> District </a>
                                </li>
                                 <li>
                                    <a href="paroise.php"> <i class="fas fa-home"></i> Paroisse </a>
                                </li>

                                        <li>
                                    <a href="centrale.php"> <i class="fas fa-home"></i> Centrale </a>
                                </li>
                                      <li>
                                    <a href="sucrisale.php"> <i class="fas fa-home"></i> Sucrisale </a>
                                </li>
                                      <li>
                                    <a href="umuryangoremezo.php"> <i class="fas fa-home"></i> Umuryangoremezo </a>
                                </li>

                                <li>
                                    <a href="payment_mode.php"> <i class="fas fa-credit-card"></i> Payment mode </a>
                                </li>
                                 <li>
                                    <a href="permission.php"> <i class="fas fa-flag"></i> Permission </a>
                                </li>
                                 <li>
                                    <a href="users.php"> <i class="fas fa-user"></i> Users </a>
                                </li>
                                 <li>
                                    <a href="customer_details.php"> <i class="fas fa-user"></i> Customer details </a>
                                </li>
                            
                                 <li>
                                    <a href="complete_installation_payment.php"> <i class="fas fa-credit-card"></i> Payment </a>
                                </li>
                               
                                 <li>
                                    <a href="permission_level.php"> <i class="fas fa-flag"></i>Permission Level </a>
                                </li>
                                 <li>
                                    <a href="system_module.php"> <i class="fas fa-gear"></i> System module </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>
<?php
}
if ($access==="installer") {
?>
 <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="#">
                    <img src="images/icon/logo.png"  />
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                 



                          
     <li>
     <a href="client_form.php"> <i class="fas fa-user"></i>After installation </a>
     </li>

                     

     <li> <a href="complete_installation.php"> <i class="fas fa-gear"></i> Complete Inst.. </a>
                                </li>

                                
                    </ul>
                </nav>
            </div>
        </aside>

<?php
}
if ($access==="accountant") {
  ?>

 <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="#">
                    <img src="images/icon/logo.png"  />
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                                 <li>
                                    <a href="manage_customer.php"> <i class="fas fa-warehouse"></i> Manage Customers </a>
                                </li>
                            <li>
                                    <a href="payment_made.php"> <i class="fas fa-warehouse"></i> Add Payment </a>
                                </li>
                                <li>
                                    <a href="customers.php"> <i class="fas fa-warehouse"></i> Record Customers </a>
                                </li>
                                <li>
                                    <a href="payments.php"> <i class="fas fa-credit-card"></i> Payments Made</a>
                                </li>
                       
                           
                          
                            </ul>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>
<?php
}
if ($access==="paroise") {
 ?>

 <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="#">
                    <img src="images/icon/logo.png"  />
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">


                                 <!-- <li>
                                    <a href="customers.php"> <i class="fas fa-warehouse"></i> Record Customers </a>
                                </li>
                               <li>
                                    <a href="sent_customers.php"> <i class="fas fa-warehouse"></i> Status Customers </a>
                                </li>
      
                                 <li>
                                    <a href="assign_kits_installer.php"> <i class="fas fa-user"></i>Assign Kits to installers </a>
                                </li>
     <li>
                                    <a href="client_form.php"> <i class="fas fa-user"></i>After installation </a>
                                </li>

     <li>
                                    <a href="complete_installation.php"> <i class="fas fa-gear"></i> Complete Inst.. </a>
                                </li>
  <li>
                                    <a href="main_Stock.php"> <i class="fas fa-warehouse"></i> Main Stock </a>
                                </li> -->
                                <li>
                                    <a href="import/index.php"> <i class="fas fa-warehouse"></i> Import Customers </a>
                                </li>

                         
                                  <li>
                                    <a href="sent_customers.php"> <i class="fas fa-warehouse"></i>Sent Customer </a>
                                </li>

                                  <li>
                                    <a href="manage_customer.php"> <i class="fas fa-warehouse"></i> All Customers </a>
                                </li>

     <li>
                                    <a href="payment_made.php"> <i class="fas fa-warehouse"></i> Add Payment </a>
                                </li>

                                 <li>
                                    <a href="customers.php"> <i class="fas fa-warehouse"></i> Record New Customers </a>
                                </li>
                
                                 <li>
                                    <a href="assign_kits_installer.php"> <i class="fas fa-user"></i>Kits to installers </a>
                                </li>
                                <li>
                                    <a href="payment_details.php"> <i class="fas fa-user"></i>Customer Payments</a>
                                </li>

                                <li>
                                    <a href="complete_installation.php"> <i class="fas fa-gear"></i> Complete Installation </a>
                                </li>
                                 <li>
                                    <a href="main_Stock.php"> <i class="fas fa-warehouse"></i>Record New Kits </a>
                                </li>
                                  <li>
                                    <a href="manage_kit.php"> <i class="fas fa-warehouse"></i>Manage New Kits </a>
                                </li>

                                    <li>
                                    <a href="manage_kit.php"> <i class="fas fa-warehouse"></i>Manage New Kits </a>
                                </li>

                                
                            
                    </ul>
                </nav>
            </div>
        </aside>
<?php
}

if ($access==="unknown") {
  ?>
<script type="text/javascript">
  alert("We can not determine your permission level ID please Contact the system administrator");
  window.location="logout.php";
</script>
  <?php
}

        ?>