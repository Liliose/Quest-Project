 <nav class="sidebar">
     <div class="logo d-flex justify-content-between">
         <a class="large_logo" href="index.html"><img src="img/logo.png" alt="" /></a>
         <a class="small_logo" href="index.html"><img src="img/mini_logo.png" alt="" /></a>
         <div class="sidebar_close_icon d-lg-none">
             <i class="ti-close"></i>
         </div>
     </div>
     <ul id="sidebar_menu">


 <li class="" style="background: red;color:white;">
             <a class="has-arrow" href="#pages.php" aria-expanded="false" style="background: red;color:white;">

                 <div class="nav_icon_small">
                     <img src="img/menu-icon/2.svg" alt="" />
                 </div>
                 <div class="nav_title">
                     <span>Admin Menu  </span>
                 </div>
             </a>
             
         </li>


 <li class="" >
             <a class="has-arrow" href="#pages.php" aria-expanded="false" >

                 <div class="nav_icon_small">
                     <img src="img/menu-icon/2.svg" alt="" />
                 </div>
                 <div class="nav_title">
                     <span>Projects  </span>
                 </div>
             </a>
             <ul>
                 <li><a href="#">Projects List </a></li>
               <li><a href="add_project.php">Add Project </a></li>
              
             </ul>
         </li>



   <li class="">
             <a class="has-arrow" href="#" aria-expanded="false">
                 <div class="nav_icon_small">
                     <img src="img/menu-icon/dashboard.svg" alt="" />
                 </div>
                 <div class="nav_title">
                     <span>Categories  </span>
                 </div>
             </a>
             <ul>
                 <li><a href="#">Category List </a></li>
               <li><a href="add_category.php">Add Category </a></li>
              
             </ul>
         </li>
   <li class="">
             <a class="has-arrow" href="#" aria-expanded="false">
                 <div class="nav_icon_small">
                     <img src="img/menu-icon/dashboard.svg" alt="" />
                 </div>
                 <div class="nav_title">
                     <span>Proposal  </span>
                 </div>
             </a>
             <ul>
                 <li><a href="#">Proposal List </a></li>
               <li><a href="#">Received Proposal </a></li>
               <li><a href="add_proposal.php">Add Proposal</a></li>
              
             </ul>
         </li>

   <li class="">
             <a class="has-arrow" href="#" aria-expanded="false">
                 <div class="nav_icon_small">
                     <img src="img/menu-icon/dashboard.svg" alt="" />
                 </div>
                 <div class="nav_title">
                     <span>Pay Questgis Pro  </span>
                 </div>
             </a>
          
         </li>
   <li class="">
             <a class="has-arrow" href="chat.php" aria-expanded="false">
                 <div class="nav_icon_small">
                     <img src="img/menu-icon/dashboard.svg" alt="" />
                 </div>
                 <div class="nav_title">
                     <span>Chat client </span>
                 </div>
             </a>
            
         </li>
            <li class="">
             <a class="has-arrow" href="chat.php" aria-expanded="false">
                 <div class="nav_icon_small">
                     <img src="img/menu-icon/dashboard.svg" alt="" />
                 </div>
                 <div class="nav_title">
                     <span>Chat Questgis Pro </span>
                 </div>
             </a>
            
         </li>
   <li class="">
             <a class="has-arrow" href="#" aria-expanded="false">
                 <div class="nav_icon_small">
                     <img src="img/menu-icon/dashboard.svg" alt="" />
                 </div>
                 <div class="nav_title">
                     <span>Site settings  </span>
                 </div>
             </a>
             <ul>
             <li><a href="#">Site Settings </a></li>
             <li><a href="#">payment Settings </a></li>
             <li><a href="#">Currency Settings </a></li>
             <li><a href="#">Email Settings </a></li>
             <li><a href="#">How Settings </a></li>
             <li><a href="#">Faq Settings </a></li>
                   

              
             </ul>
         </li>

 <li class="" style="background: red;color:white;">
             <a class="has-arrow" href="#pages.php" aria-expanded="false" style="background: red;color:white;">
                 <div class="nav_icon_small">
                     <img src="img/menu-icon/2.svg" alt="" />
                 </div>
                 <div class="nav_title">
                     <span>Questgis pro menu </span>
                 </div>
             </a>
             
         </li>

    <li class="">
             <a class="has-arrow" href="#projects.php" aria-expanded="false">
                 <div class="nav_icon_small">
                     <img src="img/menu-icon/2.svg" alt="" />
                 </div>
                 <div class="nav_title">
                     <span>View Projects </span>
                 </div>
             </a>
             
         </li>
         
   <li class="">
             <a class="has-arrow" href="pages.php" aria-expanded="false">
                 <div class="nav_icon_small">
                     <img src="img/menu-icon/2.svg" alt="" />
                 </div>
                 <div class="nav_title">
                     <span>Submit Proposals </span>
                 </div>
             </a>
             
         </li>
 <li class="">
             <a class="has-arrow" href="chat.php" aria-expanded="false">
                 <div class="nav_icon_small">
                     <img src="img/menu-icon/2.svg" alt="" />
                 </div>
                 <div class="nav_title">
                     <span>Chat with admin  </span>
                 </div>
             </a>
             
         </li>

 <li class="">
             <a class="has-arrow" href="#complete_project.php" aria-expanded="false">
                 <div class="nav_icon_small">
                     <img src="img/menu-icon/2.svg" alt="" />
                 </div>
                 <div class="nav_title">
                     <span>Complete Project </span>
                 </div>
             </a>
             
         </li>

 <li class="">
             <a class="has-arrow" href="#profile.php" aria-expanded="false">
                 <div class="nav_icon_small">
                     <img src="img/menu-icon/2.svg" alt="" />
                 </div>
                 <div class="nav_title">
                     <span>Profile  </span>
                 </div>
             </a>
             
         </li>

 <li class="">
             <a class="has-arrow" href="logout.php" aria-expanded="false">
                 <div class="nav_icon_small">
                     <img src="img/menu-icon/2.svg" alt="" />
                 </div>
                 <div class="nav_title">
                     <span>Logout  </span>
                 </div>
             </a>
             
         </li>
 <li class="" style="background: red;color:white;">
             <a class="has-arrow" href="#pages.php" aria-expanded="false" style="background: red;color:white;">
 
                 <div class="nav_icon_small">
                     <img src="img/menu-icon/2.svg" alt="" />
                 </div>
                 <div class="nav_title">
                     <span>Client Menu  </span>
                 </div>
             </a>
             
         </li>

 <li class="">
             <a class="has-arrow" href="#project_add.php" aria-expanded="false">
                 <div class="nav_icon_small">
                     <img src="img/menu-icon/2.svg" alt="" />
                 </div>
                 <div class="nav_title">
                     <span>Add Project  </span>
                 </div>
             </a>
             
         </li>
 <li class="">
             <a class="has-arrow" href="#proposal.php" aria-expanded="false">
                 <div class="nav_icon_small">
                     <img src="img/menu-icon/2.svg" alt="" />
                 </div>
                 <div class="nav_title">
                     <span>View Project proposal </span>
                 </div>
             </a>
             
         </li>
 <li class="">
             <a class="has-arrow" href="logout.php" aria-expanded="false">
                 <div class="nav_icon_small">
                     <img src="img/menu-icon/2.svg" alt="" />
                 </div>
                 <div class="nav_title">
                     <span>Pay online  </span>
                 </div>
             </a>
             
         </li>

 <li class="">
             <a class="has-arrow" href="chat.php" aria-expanded="false">
                 <div class="nav_icon_small">
                     <img src="img/menu-icon/2.svg" alt="" />
                 </div>
                 <div class="nav_title">
                     <span>Chat with admin  </span>
                 </div>
             </a>
             
         </li>

 <li class="">
             <a class="has-arrow" href="#profile.php" aria-expanded="false">
                 <div class="nav_icon_small">
                     <img src="img/menu-icon/2.svg" alt="" />
                 </div>
                 <div class="nav_title">
                     <span>Profile  </span>
                 </div>
             </a>
             
         </li>
 <li class="">
             <a class="has-arrow" href="logout.php" aria-expanded="false">
                 <div class="nav_icon_small">
                     <img src="img/menu-icon/2.svg" alt="" />
                 </div>
                 <div class="nav_title">
                     <span>Logout  </span>
                 </div>
             </a>
             
         </li>


       </ul>
 </nav>