<?php session_start();
if(!isset($_SESSION['username'])) {
   $_SESSION['error']= 'Set and not empty, and no undefined index error!';
  ?>
<script type="text/javascript">
	alert("Please login again ");
	window.location="login.php";
</script>
<?php
}

$user_id=$_SESSION['user_id'];
/*echo $_SESSION['username'];*/
?>