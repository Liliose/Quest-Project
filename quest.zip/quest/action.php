<?php session_start();
include "class/connection.php";
 include "class/useraction_class.php";
 $record_date=date("d/m/Y h:i:s");
$user_id=$_SESSION['user_id'];
//lets now see what the user is trying to do
// lets get all posts
//lets get the action second
$action_Request = $_POST['action_name'];
$url_slug = $_POST['action_name'];
$data = new useractions();
$date_added = $data->return_todaydate();
switch ($action_Request) {
case "province_save":
 $province_name=$_POST['province_name'];
  //lets now save province
$feed = $data->registerprovince($province_name,$date_added);
break;

case "paroise_save":
$paroise_name=$_POST['paroise_name'];
$district_id=$_POST['district_id'];
  //lets now save province
$feed = $data->registerparoise($paroise_name,$district_id,$date_added);
break;

case "payment_method_save":
$method_name=$_POST['method_name'];
//lets now save province
$feed = $data->registerpayment_mode($method_name);
break;

case "system_module":
$system_module=$_POST['module_name'];
$module_status=$_POST['module_status'];
  //lets now save province
$feed = $data->registersystem_modules($system_module, $module_status, $date_added);
break;

case "permission_level_save":
$level_name=$_POST['level_name'];

  //lets now save province
$feed = $data->registerpermission_levels($level_name, $date_added);
break;

case "user_save":
$first_name=$_POST['firstname'];
$last_name=$_POST['lastname'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$national_id=$_POST['national_id'];
$paroise_id=$_POST['paroise_id'];
$user_level_id=$_POST['user_level'];
$status=$_POST['status'];
$password=$_POST['password'];
  //lets now save province
$feed = $data->registerUsers($first_name, $last_name, $national_id, $phone, $email, $password, $user_level_id, $paroise_id, $status,$date_added);
break;


case "main_stock":
$kit_serial_number=$_POST['kit_serial_number'];
$kit_category=$_POST['kit_category'];
$kit_description=$_POST['kit_description'];
$kit_status=$_POST['kit_status'];
$kit_image="kit_image";
//$kit_image=$data->upload($_FILES["kit_image"]["name"],$temp);

/*
$target_dir = "media/";
$target_file = $target_dir . basename($target_file,$temp);
move_uploaded_file($_FILES["$temp"]["tmp_name"], $target_file);
  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
    echo "The file ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.";
  } else {
    echo "Sorry, there was an error uploading your file.";
  }*/
//lets now save province
$feed = $data->register_main_stock($kit_serial_number, $kit_image, $kit_category, $kit_description, $date_added, $kit_status);
break;

case "customer_save":
$cust_fname=$_POST['first_name'];
$cust_mname=$_POST['middle_name'];
$cust_lname=$_POST['last_name'];
$cust_email=$_POST['email'];
$cust_phone_number=$_POST['phone'];
$cust_national_id=$_POST['national_id'];
$cust_sector=$_POST['sector_name'];
$cust_district=$_POST['district_name'];
$cust_cell=$_POST['cell_name'];
$cust_village=$_POST['village_name'];
$cust_cell=$_POST['cell_name'];
$cust_gender=$_POST['gender'];
$cust_ubudehe=$_POST['ubudehe'];

$paroisse_id=$_POST['paroisse_id'];
$umuryango_id=$_POST['umuryango_id'];
$suscrisale_id=$_POST['sucrisale_id'];
$isibo=$_POST['isibo_name'];
$full_address=$_POST['full_address'];

//lets now save customers

$record_date=date("d/m/Y h:i:s");
$user_id=$_SESSION['user_id'];
$res=$conn->query("INSERT INTO customer_details VALUES ('$cust_national_id','$record_date','$user_id','NULL','NULL','3')");

$feed = $data->registercustomer($cust_national_id, $cust_fname, $cust_mname, $cust_lname, $cust_phone_number, $cust_email, $cust_district, $cust_sector, $cust_cell, $cust_village, $cust_gender, $cust_ubudehe,$paroisse_id,$umuryango_id,$suscrisale_id,$isibo,$full_address);
break;

case "complete_installation_save":
$cust_installed_national_id=$_POST['national_id'];
$installer_id=$_POST['installer_id'];
$kit_installed_serial_number=$_POST['serial_number'];
$installation_date=$_POST['installation_date'];
$temp="img1";
$image_a=$data->upload($_FILES["img1"]["name"],$temp);
$temp="img2";
$image_b=$data->upload($_FILES["img2"]["name"],$temp);
$temp="img3";
$image_c=$data->upload($_FILES["img3"]["name"],$temp);
//lets now save province
$feed = $data->registercomplete_installation($cust_installed_national_id, $installer_id, $kit_installed_serial_number, $installation_date, $image_a, $image_b, $image_c);
break;

case "district_save":
$district_name=$_POST['district_name'];
$province_id=$_POST['province_id'];
  //lets now save province
$feed = $data->registerdistrict($district_name,$province_id,$date_added);
break;


case "permission_save":
$admin=$_POST['admin_value'];
$paroise=$_POST['paroise_value'];
$agent=$_POST['agent_value'];
$accountant=$_POST['accountant_value'];
$installer=$_POST['installer_value'];
$module_id=$_POST['module_id'];
//lets now save province
$feed = $data->registerpermissions($module_id, $admin, $agent, $installer, $paroise, $accountant);
break;

case "payment_save":
$admin=$_POST['admin_value'];
$national_id=$_POST['national_id'];
$account_number=$_POST['account_number'];
$account_name=$_POST['account_name'];
$payment_method=$_POST['payment_method'];
$sacco_branch=$_POST['sacco_branch'];
$to_date=$_POST['to_date'];
$from_date=$_POST['from_date'];
$monthly_installement=$_POST['monthly_installement'];
$means_of_payment=$_POST['means_of_payment'];
$months=$_POST['months'];
$payment_reference="GDG".date("dmYhis");
$status="0";
//lets now save province
$feed = $data->register_payment($payment_reference,$national_id, $payment_method, $months, $monthly_installement, $from_date, $to_date, $means_of_payment, $sacco_branch, $account_name, $account_number, $status, $user_id, $date_added);
break;
case "assign_kit_installer_save":
$national_id=$_POST['national_id'];
$serial_number=$_POST['serial_number'];

//lets now save province
$feed = $data->register_assign_installer($national_id, $serial_number, $date_added);
break;

default:
die("You are not allowed to perform this action");
}
$page=$data->redirect_page($url_slug);
@$url=$url_slug;
echo $response=$feed;
$resp=$data->message($url,$response);
header("location:$page");
?>