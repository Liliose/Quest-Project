<?php session_start();
if(isset($_SESSION['login']===true)) {
   $_SESSION['error']= 'Set and not empty, and no undefined index error!';
header("location:login.php");
}
?>