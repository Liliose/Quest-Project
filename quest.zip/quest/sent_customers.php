<?php include "includes/header.php";
function determine_status($cust_national_id){
include "class/connection.php";
$select="SELECT * FROM customer_details WHERE cust_d_national_id='$cust_national_id'";
$data=$conn->query($select);
if ($data->num_rows > 0) {
$row=$data->fetch_assoc();
if ($row['cust_d_status']==0) {
  $status="Submitted / Approve ?";
}
if ($row['cust_d_status']==1) {
  $status="Accepted";
}
if ($row['cust_d_status']==2) {
  $status="Rejected";
}
if ($row['cust_d_status']==3) {
  $status="Waiting Paroisse";
}
return $status;
}
else
{
  return "Not yet Submitted";
}

}
function define_btn($status,$id){

switch ($status) {
  case "Accepted":
    $btn="class='btn btn-success'";
    break;
  case "Not yet Submitted":
    $btn="class='btn btn-danger'";
    break;
  case "Rejected":
    $btn="class='btn btn-dark'";
    break;
  case "Submitted / Approve ?":
    $btn="class='btn btn-info' onclick='approve_customer($id)'";
    break;
  default:
    $btn="class='btn btn-secondary'";
}
return $btn;
}
?>


<body class="animsition">
	<div class="page-wrapper">
		<!-- HEADER MOBILE-->
		<header class="header-mobile d-block d-lg-none">
			<div class="header-mobile__bar">
				<div class="container-fluid">
					<div class="header-mobile-inner">
						<a class="logo" href="index.html">
							<img src="images/icon/logo.png"  />
						</a>
						<button class="hamburger hamburger--slider" type="button">
							<span class="hamburger-box">
								<span class="hamburger-inner"></span>
							</span>
						</button>
					</div>
				</div>
			</div>
			   <?php
include "includes/navbar.php";
?>
</header>
<!-- END HEADER MOBILE-->
   <?php
include "includes/aside.php";
?>

		<!-- END MENU SIDEBAR-->

		<!-- PAGE CONTAINER-->
		<div class="page-container">
			<!-- HEADER DESKTOP-->
		<?php
include "includes/header_menu.php";?>
		?>
			<!-- END HEADER DESKTOP-->

			<!-- MAIN CONTENT-->
			<div class="main-content">
				<div class="section__content section__content--p30">
					<div class="container-fluid">		
						<div class="row">
							   <div class="col-lg-12">
                                <div class="card">
                                       <div class="card-header">Customers</div>
                                    <div class="card-body">
                                        <div class="card-title">
                                            <h3 class="text-center title-2">List of submitted customer </h3>
                                        </div>
                                        <div><a href="javascript:void(0)" onclick="export_customers()" class="btn btn-secondary" style="margin-bottom: 10px;">Export All Submitted Customers</a>
                                        </div>
                                  <table class="table table-stripped">
<tr><th>ID</th><th>Customer Name</th><th>National ID</th><th>Phone</th><th>District</th><th>Gender</th><th>Status</th></tr>

<?php
$no=0;
$select="SELECT * FROM customers inner join district,sector,cell,village,sucrisale,paroise where customers.cust_district=district.district_id and customers.cust_sector=sector.sector_id and customers.cust_cell=cell.cell_id and customers.cust_village=village.village_id and customers.suscrisale_id = sucrisale.id and customers.paroisse_id=paroise.paroise_id order by cust_fname asc";
$data=$conn->query($select);
if ($data->num_rows > 0) {
  while ($row=$data->fetch_assoc()) {
  	$no=$no+1;
  	$id=$row['cust_national_id'];
  	$uni=$row['cust_national_id'];
    echo "<tr><td>$no</td><td>$row[cust_fname] $row[cust_mname] $row[cust_lname]</td><td>$row[cust_national_id]</td><td>$row[cust_phone_number]</td><td>$row[district_name]</td><td>$row[cust_gender]</td><td><a href='javascript:void(0)' ".define_btn(determine_status($row['cust_national_id']),$id)." id='$id'>".determine_status($row['cust_national_id'])."</a> &nbsp;&nbsp;&nbsp;<a href='javascript:void(0)' onClick=\"updateId('$row[cust_national_id]$row[cust_lname]')\" class='btn btn-dark'>View Details</a> &nbsp; &nbsp;";

if (determine_status($id)==="Submitted / Approve ?") {
	echo "<a href='javascript:void(0)' onClick='reject_customer($row[cust_national_id])' class='btn btn-danger'> <i class='fa fa-trash'></i> </a> ";
}
     echo "</td></tr>";


    echo "<tr style='display:none;' id='$row[cust_national_id]$row[cust_lname]'><td colspan='6'><div >";
echo "
<span>Names: $row[cust_fname] $row[cust_mname] $row[cust_lname]</span>  &nbsp;&nbsp;<span>National ID: $row[cust_national_id]</span> <br>
<span>Phone number: $row[cust_phone_number]</span>  &nbsp;&nbsp;<span>Email: $row[cust_email]</span><br>
<span>Province:  $row[cust_email]</span>  &nbsp;&nbsp;<span>Cell :  $row[cell_name]</span><br>
<span>District:  $row[district_name]</span>  &nbsp;&nbsp;<span>Village:  $row[village_name]</span><br>
<span>Sector:  $row[sector_name]</span>  &nbsp;&nbsp;<span>Gender:  $row[cust_gender]</span><br>
<span>Paroisse:  $row[paroise_name]</span>  &nbsp;&nbsp;<span>Suscrisale :  $row[name]</span><br>
<span>Umuryango Remezo:  $row[cust_email]</span>  &nbsp;&nbsp;<span>Isibo:  $row[isibo]</span><br>
<span>Full address:  $row[full_address]</span> 
";



echo " </div></td><tr>";
  }
}

?>




                                  </table>
                                      
                                      
                                    </div>
                              					<!-- /# column -->
							
							<!-- /# column -->
						</div>
					</div>
				</div>
			</div>
			<!-- END PAGE CONTAINER-->

		</div>

            <script>
function approve_customer(id)
{
	/*id="1199680133409030";*/
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) 
        {
document.getElementById(xmlhttp.responseText).classList.remove="btn btn-info";
document.getElementById(xmlhttp.responseText).classList.add="btn btn-danger";
document.getElementById(xmlhttp.responseText).innerHTML= "Approved";
        }
    };
    xmlhttp.open("GET", "update_customer.php?id=" +id, true);
    xmlhttp.send();
}
</script>

            <script>
function reject_customer(id)
{
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) 
        {
document.getElementById(xmlhttp.responseText).classList.remove="btn btn-info";
document.getElementById(xmlhttp.responseText).classList.add="btn btn-danger";
document.getElementById(xmlhttp.responseText).innerHTML= "Rejected";
        }
    };
    xmlhttp.open("GET", "reject_customer.php?id=" +id, true);
    xmlhttp.send();
}
</script>




            <script>
function updateId(ids)
{
x = document.getElementById(ids);
if(x.style.display=="none"){
  x.style.display="block";

}
else
{
	x.style.display="none";
}



  
  
}
</script>
		<!-- Jquery JS-->
		<script src="vendor/jquery-3.2.1.min.js"></script>
		<!-- Bootstrap JS-->
		<script src="vendor/bootstrap-4.1/popper.min.js"></script>
		<script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
		<!-- Vendor JS       -->
		<script src="vendor/slick/slick.min.js">
		</script>
		<script src="vendor/wow/wow.min.js"></script>
		<script src="vendor/animsition/animsition.min.js"></script>
		<script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
		</script>
		<script src="vendor/counter-up/jquery.waypoints.min.js"></script>
		<script src="vendor/counter-up/jquery.counterup.min.js">
		</script>
		<script src="vendor/circle-progress/circle-progress.min.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
		<script src="vendor/chartjs/Chart.bundle.min.js"></script>
		<script src="vendor/select2/select2.min.js">
		</script>

		<!-- Main JS-->
		<script src="js/main.js"></script>

</body>

</html>
<!-- end document-->
<script type="text/javascript">
	
function export_customers(){
	window.location="export/index.php";
}






</script>


