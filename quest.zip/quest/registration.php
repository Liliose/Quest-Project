<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    
    <!--====== Title ======-->
    <title>Amasezerano</title>
    
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="assets/images/favicon.png" type="image/png">
        
    <!--====== Magnific Popup CSS ======-->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
        
    <!--====== Slick CSS ======-->
    <link rel="stylesheet" href="assets/css/slick.css">
        
    <!--====== Line Icons CSS ======-->
    <link rel="stylesheet" href="assets/css/LineIcons.css">
        
    <!--====== Bootstrap CSS ======-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    
    <!--====== Default CSS ======-->
    <link rel="stylesheet" href="assets/css/default.css">
    
    <!--====== Style CSS ======-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="assets/css/style.css">
   <style>

body{
    overflow:scroll;
    overflow-x:hidden;
}

/* width */
::-webkit-scrollbar {
  width: 9px;
}

/* Track */
::-webkit-scrollbar-track {
  background: #f1f1f1; 
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: #085ffc; 
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #1e57bd; 
}
/* Float four columns side by side */
.column {
  float: left;
  width: 33.3%;
  padding: 0 10px;

}

/* Remove extra left and right margins, due to padding */
.row {margin: 0 -5px;}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive columns */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
    display: block;
    margin-bottom: 20px;
  }
}

/* Style the counter cards */
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  text-align: center;
  background-color: #ffffff;
    height:250px;
    margin-bottom:40px;
}

.spacer{
    margin-top:100px;
    display:block;
}
.spacer2{
    margin-top:100px;
    display:block;
}
</style> 
</head>

<body style="background-color:#007bff">
    <!--[if IE]>
    <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
  <![endif]-->
   
    <!--====== PRELOADER PART START ======-->

    <div class="preloader">
        <div class="loader">
            <div class="ytp-spinner">
                <div class="ytp-spinner-container">
                    <div class="ytp-spinner-rotator">
                        <div class="ytp-spinner-left">
                            <div class="ytp-spinner-circle"></div>
                        </div>
                        <div class="ytp-spinner-right">
                            <div class="ytp-spinner-circle"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--====== PRELOADER PART ENDS ======-->
    
    <!--====== NAVBAR TWO PART START ======-->

    <section class="navbar-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <nav class="navbar navbar-expand-lg">
                       
                        
                           <label style="font-size:30px;font-weight:bold;color:white;">Amasezerano</label>
                        
                        
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTwo" aria-controls="navbarTwo" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="toggler-icon"></span>
                            <span class="toggler-icon"></span>
                            <span class="toggler-icon"></span>
                        </button>

                        <div class="collapse navbar-collapse sub-menu-bar" id="navbarTwo">
                            <ul class="navbar-nav m-auto">
                                <li class="nav-item active"><a class="page-scroll" href="index.php">Ahabanza</a></li>
                                <li class="nav-item"><a class="page-scroll" href="admin/registration.php">Iyandikishe</a></li>
                                <li class="nav-item"><a class="page-scroll" href="admin/login.php">Injira</a></li>
                                                        </ul>
                        </div>
                        
                        <div class="navbar-btn d-none d-sm-inline-block">
                            <ul>
                                <li><a class="solid" href="#">Koresha application yacu</a></li>
                            </ul>
                        </div>
                    </nav> <!-- navbar -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>

    <!--====== NAVBAR TWO PART ENDS ======-->
    
    <!--====== SLIDER PART START ======-->

    <section id="home" class="slider_area">
        <div id="carouselThree" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselThree" data-slide-to="0" class="active"></li>
                <li data-target="#carouselThree" data-slide-to="1"></li>
                <li data-target="#carouselThree" data-slide-to="2"></li>
            </ol>

            <div class="carousel-inner">
                

                <div class="carousel-item active">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6">
                               <div class="slider-content">
                                    <h1 class="title">Amasezerano</h1>
                                    <p class="text">Ubu kugirana amasezerano yemewe namategeko ubu byaroroshye tugane tugufashe</p>
                                   
                                    <ul class="slider-btn rounded-buttons">
                                        <li><a class="main-btn rounded-one" href="admin/registration.php">Tangira</a></li>
                                       <!-- <li><a class="main-btn rounded-two" href="#">DOWNLOAD</a></li>-->
                                    </ul>
                                </div> <!-- slider-content -->
                            </div>
                        </div> <!-- row -->
                    </div> <!-- container -->
                    <div class="slider-image-box d-none d-lg-flex align-items-end">
                        <div class="slider-image">
                            <img src="assets/images/slider/2.png" alt="Hero">
                        </div> <!-- slider-imgae -->
                    </div> <!-- slider-imgae box -->
                </div> <!-- carousel-item -->

                <div class="carousel-item">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="slider-content">
                                    <h1 class="title">Amasezerano</h1>
                                    <p class="text">Nigute Bikora ?</p>
                                 <p class="text">  Iyandikishe , winjire muri system ubundi ukurikize amabwiriza</p>
                                    <ul class="slider-btn rounded-buttons">
                                        <li><a class="main-btn rounded-one" href="admin/registration.php">Tangira</a></li>
                                       
                                    </ul>
                                </div> <!-- slider-content -->
                            </div>
                        </div> <!-- row -->
                    </div> <!-- container -->
                    <div class="slider-image-box d-none d-lg-flex align-items-end">
                        <div class="slider-image">
                            <img src="assets/images/slider/3.png" alt="Hero">
                        </div> <!-- slider-imgae -->
                    </div> <!-- slider-imgae box -->
                </div> <!-- carousel-item -->
                <div class="carousel-item">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="slider-content">
                                    <h1 class="title">Impamvu  </h1>
                                    <p class="text">Ubu byoroshye, uzajya wuzuza form tuguhaye , wishyure , ubundi tubiguhere noteri abyemeze ugende ugiye gufata amasezerano yawe yemewe namategeko</p>
                                    <p class="text">Byose mugihe gito gishoboka </p>
                                    <ul class="slider-btn rounded-buttons">
                                        <li><a class="main-btn rounded-one" href="admin/registration.php">TANGIRA HANO</a></li>
                                       
                                    </ul>
                                </div>
                            </div>
                        </div> <!-- row -->
                    </div> <!-- container -->
                    <div class="slider-image-box d-none d-lg-flex align-items-end">
                        <div class="slider-image">
                            <img src="assets/images/slider/1.png" alt="Hero">
                        </div> <!-- slider-imgae -->
                    </div> <!-- slider-imgae box -->
                </div> <!-- carousel-item -->
            </div>

            <a class="carousel-control-prev" href="#carouselThree" role="button" data-slide="prev">
                <i class="lni lni-arrow-left"></i>
            </a>
            <a class="carousel-control-next" href="#carouselThree" role="button" data-slide="next">
                <i class="lni lni-arrow-right"></i>
            </a>
        </div>
    </section>

    <!--====== SLIDER PART ENDS ======-->
    <div class="row">
  <div class="column">
    <div class="card">
      <h5>MOTOR VEHICLE SALES AGREEMENT</h5>
      <p>Amasezerano y'ubugure bwibinyabiziga</p>
      <span class="spacer"></span>
          <center> <a href="admin/login.php" class="btn btn-success" style="background-color:#325ca8;color:white;width:200px;" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal"> TANGIRA</a></center>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <h3>land sales agreement</h3>
      <p>Amasezerano yubugure bw'ubutaka</p>
            <span class="spacer"></span>
             <center> <a href="admin/login.php" class="btn btn-success" style="background-color:#325ca8;color:white;width:200px;" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#plotregistration"> TANGIRA</a></center>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
      <h3>Documents notification<br>umukono wa noteri</h3>
      <p>School document</p>
      <p>Lease / Rent Documents</p>
       <p>Bank Documents</p>
        <p>Others Documents</p>
          <center> <a href="admin/login.php" class="btn btn-success" style="background-color:#325ca8;color:white;width:200px;" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#normalregistration"> TANGIRA</a></center>
      
    </div>
  </div>
  
  <div class="column">
    <div class="card">
      <h3>House Sales agreement</h3>
      <p>Amasezerano y'ubugure bw'inzu</p>
            <span class="spacer"></span>
       <center> <a href="admin/login.php" class="btn btn-success" style="background-color:#325ca8;color:white;width:200px;" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#houseregistration"> TANGIRA</a></center>
    </div>
  </div>
    <div class="column">
    <div class="card">
      <h3>Procuration</h3>
      <p>Ihesha bubasha</p>
            <span class="spacer2"></span>
           <center> <a href="admin/login.php" class="btn btn-success" style="background-color:#325ca8;color:white;width:200px;" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#procuration"> TANGIRA</a></center>
    </div>
  </div>
</div>
    <!--====== FEATRES TWO PART START ======-->

   
   
    <section class="footer-area footer-dark" style="background-color:#0067f4;">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="footer-logo text-center">
                        <a class="mt-30" href="index.html"><img src="assets/images/logo.svg" alt="Logo"></a>
                    </div> <!-- footer logo -->
                    <ul class="social text-center mt-60">
                        <li><a href="https://facebook.com/uideckHQ"><i class="lni lni-facebook-filled"></i></a></li>
                        <li><a href="https://twitter.com/uideckHQ"><i class="lni lni-twitter-original"></i></a></li>
                        <li><a href="https://instagram.com/uideckHQ"><i class="lni lni-instagram-original"></i></a></li>
                        <li><a href="#"><i class="lni lni-linkedin-original"></i></a></li>
                    </ul> <!-- social -->
                    <div class="footer-support text-center">
                        <span class="number">+25078xxxxxx</span>
                        <span class="mail">support@amasezerano.com</span>
                    </div>
                    <div class="copyright text-center mt-35">
                        
                    </div> <!--  copyright -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>






<!-- Button trigger modal -->

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Igura ryikinyabiziga</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Car type/Brand</label>
 <input type="text" class="form-control" placeholder="Ubwoko bw'ikinyabiziga" name="car_type"/>
</div>

<div class="mb-3" style="display:none;">
  <label for="exampleFormControlInput1" class="form-label">Date of manufacturing</label>
    <input type="date" class="form-control" placeholder="Manufacturing Date" name="registration_date"/>
</div>

<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Plate number</label>
    <input type="text" class="form-control" placeholder="plate number" name="plate_number"/>
</div>


<div class="mb-3">
 <a href="https://irembo.gov.rw/user/citizen/service/rnp/traffic_fines" class="btn btn-info">Check Fines on  Irembo</a>
                                    <a href="https://onlinereg.rra.gov.rw/" class="btn btn-info" style="background-color:#fcb603;color:black;">Check Fines on RRA</a>
</div>


<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Nimero ya chassis</label>
   <input type="text" class="form-control" placeholder="Chassis number" name="chassis_number"/>
</div>

<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Igihe imodoka yakorewe</label>
    <input type="text" class="form-control" placeholder="Manufacturing date" name="manufacturing_date"/>
</div>
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">igurishiwe kuri </label>
   <input type="text" class="form-control" placeholder="Sold to (Names)" name="buyer_names"/>
</div>
<div class="mb-3">
  
  <label for="exampleFormControlInput1" class="form-label">Motor insurance expiry date</label>
                                <input type="date" class="form-control" name="insurance_date"/>
</div> 
<div class="mb-3">

 <label for="exampleFormControlInput1" class="form-label">Inspection Expiry Date(Igihe Control Izararangirira)</label>
                                <input type="date" class="form-control"  name="inspection_date"/>
</div>
<div class="mb-3">
 
 <label for="exampleFormControlInput1" class="form-label">Ayiguze uko iri(bought as it is)</label>
                                <input type="checkbox" class="form-control" name=""/>
</div>
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Amafaranga yishyuwe</label>
  <input type="text" class="form-control" placeholder="Amount Paid" name="amount_paid"/>
</div>
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Amafaranga asigaye</label>
 <input type="text" class="form-control" placeholder="Amount remaining (0 if none)" name="amount_remaining"/>
</div>
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Bikorewe </label>
  <input type="text" class="form-control" placeholder="Signed at (Kigali)" name="signed_at"/>
</div>
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Nimero ya telephoni yumuguzi</label>
   <input type="text" class="form-control" placeholder="Phone number of client" name="buyer_number"/>
</div>
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">irangamuntu yumuguzi</label>
  <input type="number" class="form-control" placeholder="Client ID Number" name="client_id"/>
</div>

<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Irangamuntu yumucuruzi</label>
  <input type="number" class="form-control" placeholder="Irangamuntu y'ugurisha" name="seller_id"/>
</div>

<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Amazina yabahamya</label>
 <input type="text" class="form-control" placeholder="Abahamya Names (separated by semi colomn)" name="witness_names"/>
</div>

<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Nimero y'ugurishije </label>
  <input type="text" class="form-control" placeholder="Phone number of seller" name="seller_number"/>
</div>



<div class="mb-3">
  <label for="exampleFormControlTextarea1" class="form-label">Amakuru wifuza kongeramo</label>
  <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="nb"></textarea>
</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>




    <!--====== FOOTER PART ENDS ======-->
<!-- Modal -->
<div class="modal fade" id="plotregistration" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Igura Ry'ikibanza</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Ugurisha</label>
 <input type="text" class="form-control" placeholder="Your Names *" name="seller_names"/>
</div>

<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Aho giherereye</label>
 <input type="text" class="form-control" placeholder="Your Names *" name="seller_names"/>
</div>

<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Plot number</label>
    <input type="text" class="form-control" placeholder="Plot number" name="plate_number"/>
</div>


<div class="mb-3">
 <a href="#" class="btn btn-info">Check master plan </a>
                                    <a href="https://onlinereg.rra.gov.rw/" class="btn btn-info" style="background-color:#fcb603;color:black;">Check Fines on RRA</a>
</div>





<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">igurishiwe kuri </label>
   <input type="text" class="form-control" placeholder="Selling to (Names)" name="buyer_names"/>
</div>


<div class="mb-3">
 
 <label for="exampleFormControlInput1" class="form-label">Akiguze uko iri(bought as it is)</label>
                                <input type="checkbox" class="form-control" name=""/>
</div>
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Amafaranga yishyuwe</label>
  <input type="text" class="form-control" placeholder="Amount Paid" name="amount_paid"/>
</div>
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Amafaranga asigaye</label>
 <input type="text" class="form-control" placeholder="Amount remaining (0 if none)" name="amount_remaining"/>
</div>
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Bikorewe </label>
  <input type="text" class="form-control" placeholder="Signed at (Kigali)" name="signed_at"/>
</div>
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Nimero ya telephoni yumuguzi</label>
   <input type="text" class="form-control" placeholder="Phone number of client" name="buyer_number"/>
</div>
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">irangamuntu yumuguzi</label>
  <input type="text" class="form-control" placeholder="Client ID Number" name="client_id"/>
</div>

<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Irangamuntu yumucuruzi</label>
  <input type="text" class="form-control" value="<?php if(isset($national_id)){echo $national_id; }else { echo "Auto id Failed";} ?>" name="seller_id"/>
</div>

<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Amazina yabahamya</label>
 <input type="text" class="form-control" placeholder="Abahamya Names (separated by semi colomn)" name="witness_names"/>
</div>

<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Nimero y'umuguzi </label>
  <input type="text" class="form-control" placeholder="Phone number of seller" name="seller_number"/>
</div>



<div class="mb-3">
  <label for="exampleFormControlTextarea1" class="form-label">Amakuru wifuza kongeramo</label>
  <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="nb"></textarea>
</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">funga</button>
        <button type="button" class="btn btn-primary">komeza</button>
      </div>
    </div>
  </div>
</div>





    <!--====== BACK TOP TOP PART START ======-->


<div class="modal fade" id="normalregistration" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Kunotifiya ibyangombwa</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Amazina yawe</label>
 <input type="text" class="form-control" placeholder="Tubwire amazina yawe" name="seller_names"/>
</div>

<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Aho uherereye</label>
 <input type="text" class="form-control" placeholder="aho uherereye" name="seller_names"/>
</div>

<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">ibyangombwa wifuza kunotifiya</label>
    <input type="text" class="form-control" placeholder="bank notes, school documents, transcript, (bitadnukanyijwe na ,)" name="type_document"/>
</div>








<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Duhe document ushaka ku notifiya </label>
   <input type="file" class="form-control" name="buyer_names"/>
</div>


<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Umubare wa document</label>
  <input type="text" class="form-control" placeholder="umubare wa document" name="amount_paid"/>
</div>

<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">irangamuntu yawe</label>
  <input type="text" class="form-control" placeholder="nimero y'irangamuntu yawe " name="client_id"/>
</div>



<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Nimero yawe ya telephoni </label>
  <input type="text" class="form-control" placeholder="nimero yawe ya telephoni" name="seller_number"/>
</div>



<div class="mb-3">
  <label for="exampleFormControlTextarea1" class="form-label">Amakuru wifuza kongeramo</label>
  <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="nb"></textarea>
</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">funga</button>
        <button type="button" class="btn btn-primary">Komeza</button>
      </div>
    </div>
  </div>
</div>














    <!--====== BACK TOP TOP PART START ======-->

<div class="modal fade" id="houseregistration" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header"><form id="house" method="POST">
        <h5 class="modal-title" id="exampleModalLabel">Ubugure Bw'inzu</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
<div id="house_first">
    <div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Ugurisha</label>
 <input type="text" class="form-control" placeholder="Your Names *" name="seller_names"/>
</div>
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Irangamuntu yugurisha </label>
 <input type="text" class="form-control" placeholder="irangamuntu yawe  *" name="national_id"/>
</div>
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Aho iherereye</label>
 <input type="text" class="form-control" placeholder="Plot location" name="plot_location"/>
</div>

<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">UPI number</label>
    <input type="text" class="form-control" placeholder="UPI number" name="plate_number"/>
</div>


<div class="mb-3">

                                    <a href="https://onlinereg.rra.gov.rw/" class="btn btn-info" style="background-color:#fcb603;color:black;">Check Fines on RRA</a>
</div>





<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">igurishiwe kuri </label>
   <input type="text" class="form-control" placeholder="Selling to (Names)" name="buyer_names"/>
</div>


<div class="mb-3">
 
 <label for="exampleFormControlInput1" class="form-label">Akiguze uko iri(bought as it is)</label>
                                <input type="checkbox" class="form-control" name=""/>
</div>
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Amafaranga y'ishyuwe</label>
  <input type="text" class="form-control" placeholder="Amount Paid" name="amount_paid"/>
</div>
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Amafaranga asigaye</label>
 <input type="text" class="form-control" placeholder="Amount remaining (0 if none)" name="amount_remaining"/>
</div>

<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Nimero ya telephoni yumuguzi</label>
   <input type="text" class="form-control" placeholder="Phone number of client" name="buyer_number"/>
</div>
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">irangamuntu yumuguzi</label>
  <input type="text" class="form-control" placeholder="Client ID Number" name="client_id"/>
</div>

<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Irangamuntu yumucuruzi</label>
  <input type="number" class="form-control" placeholder="Irangamuntu y'ugurisha" name="seller_id"/>
</div>

<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Amazina yabahamya</label>
 <input type="text" class="form-control" placeholder="Abahamya Names (separated by semi colomn)" name="witness_names"/>
</div>

<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Nimero y'umuguzi </label>
  <input type="number" class="form-control" placeholder="Phone number of seller" name="seller_number"/>
</div>



<div class="mb-3">
  <label for="exampleFormControlTextarea1" class="form-label">Amakuru wifuza kongeramo</label>
  <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="nb"></textarea>
</div>
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Bikorewe </label>
  <input type="text" class="form-control" placeholder="Signed at (Kigali)" name="signed_at"/>
</div>
</div>
<div id="house_seond">
    

<div class="mb-3">
  <label for="exampleFormControlTextarea1" class="form-label">telephone(uzajya ukoresha winjira)</label>
  <input type="text" class="form-control" placeholder=" tubwire number ya telephoni" name="username"/>
</div>
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">ijambo banga (uzajya ukoresha winjira) </label>
  <input type="text" class="form-control" placeholder="Duhe ijambo banga" name="password"/>
</div>

</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">funga</button>
        <button type="button" class="btn btn-primary" onclick="save_house_first()" id="button_first">komeza</button>
        <button type="button" class="btn btn-primary" onclick="save_house()" id="button_second" style="display: none;">Oherereza</button>



      </div>
    </div>
  </div></form>
</div>



    
    <!--====== BACK TOP TOP PART START ======-->



    <a href="#" class="back-to-top"><i class="lni lni-chevron-up"></i></a>


    <!--====== Jquery js ======-->
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>
    
    <!--====== Bootstrap js ======-->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    
    <!--====== Slick js ======-->
    <script src="assets/js/slick.min.js"></script>
    
    <!--====== Magnific Popup js ======-->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    
    <!--====== Ajax Contact js ======-->
    <script src="assets/js/ajax-contact.js"></script>
    
    <!--====== Isotope js ======-->
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    
    <!--====== Scrolling Nav js ======-->
    <script src="assets/js/jquery.easing.min.js"></script>
    <script src="assets/js/scrolling-nav.js"></script>
    
    <!--====== Main js ======-->
    <script src="assets/js/main.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
</body>

</html>
<script type="text/javascript">
       function save_house(){
        var query = $('#house').serialize();
        var url = 'https://urusaro.rw/save.php';
        $.post(url, query, function (response) {
alert (response);

setTimeout(function(){
//alert("Your request to save a house sales have been made ");
}, 3000);

        });

    }
function save_house_first(){
        document.getElementById('house_first').style.display="none";
        document.getElementById('house_second').style.display="block";

    document.getElementById('button_first').style.display="none";
        document.getElementById('button_second').style.display="block";

    }

</script>