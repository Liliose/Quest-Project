<?php
$dbname="shoppate_database";
$username="shoppate_datause";
$password="shoppate_database";
$host="localhost";
$conn= new mysqli($host,$username,$password,$dbname);  
	$token=$_POST['_token'];
switch ($token) {

		case 'drivers':

echo save_driver();
		break;


		case 'mechanicians':
echo	save_mechanicians();
		break;


		case 'car_rent':
echo 	save_car_rentals();
		break;


		case 'garages':
echo	save_garages();
		break;



		case 'washers':
echo    save_car_washers();
		break;



		case 'privates':
echo    save_private_car();
		break;

	
	default:
		echo "No method Provided";
		break;
}


function save_drivers(){
$dbname="shoppate_database";
$username="shoppate_datause";
$password="shoppate_database";
$host="localhost";
$conn= new mysqli($host,$username,$password,$dbname); 
$national_id=$_POST['national_id'];
$passport_number=$_POST['passport_number'];
$email=$_POST['email'];
$province=$_POST['province'];
$city=$_POST['city'];
$country=$_POST['country'];
$location=$_POST['location'];
$date_=date("Y-m-d");

		$sql = "INSERT INTO `app_drivers` (`national_id`, `passport_number`, `email_address`, `city`, `province`, `country`, `location_map`, `user_id`, `is_subscribed`, `is_active`, `expiry_date`, `date_added`) VALUES ('$national_id', '$passport_number', '$email', '$city', '$province', '$country', '$location', '$user_id', '0', '0', '0', '$date_')";
	if ($conn->query($sql)) {
		return "you have successfully registered  procced";
	} 
	else {
		return "Registering can no be done at this moment please try again later";
	}
	//mysqli_close($conn);
}

function save_car_rentals(){
$dbname="shoppate_database";
$username="shoppate_datause";
$password="shoppate_database";
$host="localhost";
$conn= new mysqli($host,$username,$password,$dbname); 
$national_id=$_POST['national_id'];
$passport_number=$_POST['passport_number'];
$email=$_POST['email'];
$province=$_POST['province'];
$city=$_POST['city'];
$country=$_POST['country'];
$location=$_POST['location'];
$family_name=$_POST['family_name'];
$first_name=$_POST['first_name'];
$tin_number=$_POST['tin_number'];
$driving_licence=$_POST['driver_licence'];
$plate_number=$_POST['plate_number'];
$model_of_car=$_POST['model_of_car'];
$expiration_date_assurance=$_POST['expiration_date_assurance'];
$company_name_assurance=$_POST['company_name_insurance'];
$phone_number=$_POST['phone_number'];
$national_id=$_POST['national_id'];
$date_=date("Y-m-d");

		$sql = "INSERT INTO `app_private_car_rentals` (`national_id`, `family_name`, `first_name`, `tin_number`, `driving_licence`, `phone_number`, `email_address`, `city`, `province`, `country`, `company_name_assurance`, `expiration_date_assurance`, `model_of_car`, `plate_number`, `cost_per_date`, `is_active`, `is_subscribed`, `expiry_date`, `user_id`) VALUES ('$national_id', '$family_name', '$first_name', '$tin_number', '$driving_licence', '$phone_number', '$email', '$city', '$province', '$country', '$company_name_assurance', '$expiration_date_assurance', '$model_of_car', '$plate_number', '$cost_per_date', '0', '0', '$date_', '$user_id')";
	if ($conn->query($sql)) {
		return "you have successfully registered  procced";
	} 
	else {
		return "Registering can no be done at this moment please try again later";
	}
	//mysqli_close($conn);
}

function save_private_car(){
$dbname="shoppate_database";
$username="shoppate_datause";
$password="shoppate_database";
$host="localhost";
$conn= new mysqli($host,$username,$password,$dbname); 
$national_id=$_POST['national_id'];
$passport_number=$_POST['passport_number'];
$email=$_POST['email'];
$company_name=$_POST['company_name'];
$tin_number=$_POST['tin_number'];
$province=$_POST['province'];
$city=$_POST['city'];
$fullname=$_POST['representative'];
$phone_number=$_POST['phone'];
$country=$_POST['country'];
$location_map=$_POST['location'];
$date_=date("Y-m-d");

		$sql = "INSERT INTO `app_private_car_rental_company` (`national_id`, `company_name`, `full_name`, `tin_number`, `phone_number`, `passport_number`, `city`, `province`, `country`, `email`, `location_map`, `user_id`) VALUES ('$national_id', '$company_name', '$fullname', '$tin_number', '$phone_number', '$passport_number', '$city', '$province', '$country', '$email', '$location_map', '$user_id')";
	if ($conn->query($sql)) {
			return "you have successfully registered  procced";
	} 
	else {
		return "Registering can no be done at this moment please try again later";
	}
	//mysqli_close($conn);
}

function save_car_washers(){
$dbname="shoppate_database";
$username="shoppate_datause";
$password="shoppate_database";
$host="localhost";
$conn= new mysqli($host,$username,$password,$dbname); 
$national_id=$_POST['national_id'];
$passport_number=$_POST['passport_number'];
$email=$_POST['email'];
$province=$_POST['province'];
$city=$_POST['city'];
$country=$_POST['country'];
$phone=$_POST['phone_number'];
$location=$_POST['location'];
$date_=date("Y-m-d");

		$sql = "INSERT INTO `app_car_washers` (`national_id`, `phone_number`, `location_map`, `city`, `province`, `country`, `user_id`, `is_active`, `is_subscribed`, `expiry_date`, `date_added`) VALUES ('$national_id', '$phone', '$location', '$city', '$province', '$country', '$user_id', '0', '0', '', '$date_')";
	if ($conn->query($sql)) {
	     	return "you have successfully registered  procced";
	} 
	else {
			return "Registering can no be done at this moment please try again later";
	}
	//mysqli_close($conn);
}

function save_driver(){
$dbname="shoppate_database";
$username="shoppate_datause";
$password="shoppate_database";
$host="localhost";
$conn= new mysqli($host,$username,$password,$dbname); 
$national_id=$_POST['national_id'];
$passport_number=$_POST['national_id'];
$email=$_POST['email'];
$province=$_POST['province'];
$city=$_POST['city'];
$country=$_POST['country'];
$location=$_POST['location'];
$date_=date("Y-m-d");

		$sql = "INSERT INTO `app_drivers` (`national_id`, `passport_number`, `email_address`, `city`, `province`, `country`, `location_map`, `user_id`, `is_subscribed`, `is_active`, `expiry_date`, `date_added`) VALUES ('$national_id', '$passport_number', '$email', '$city', '$province', '$country', '$location', '$user_id', '0', '0', '0', '$date_')";
	if ($conn->query($sql)) {
		return "you have successfully registered  procced";
	} 
	else {
	return "Registering can no be done at this moment please try again later";
	}
	//mysqli_close($conn);
}

function save_mechanicians(){
$dbname="shoppate_database";
$username="shoppate_datause";
$password="shoppate_database";
$host="localhost";
$conn= new mysqli($host,$username,$password,$dbname); 
$national_id=$_POST['national_id'];
$phone_number=$_POST['phone_number'];

$reference=$_POST['reference'];
$professionalism=$_POST['professionalism'];

$driving_license=$_POST['driving_license'];
$license_category=$_POST['license_category'];
$licence_file=$_POST['licence_file'];

$user=$_POST['username'];

$passport_number=$_POST['passport_number'];
$fullname=$_POST['fullname'];
$email=$_POST['email'];
$province=$_POST['province'];
$city=$_POST['city'];
$country=$_POST['country'];
$location=$_POST['location'];
$date_=date("Y-m-d");

		$sql = "INSERT INTO `app_mechanicians` (`National_id`, `fullname`, `passport_number`, `phone_number`, `reference`, `professionalism`, `email`, `city`, `province`, `country`, `driving_license`, `license_category`, `licence_file`, `username`, `password`, `is_active`, `is_subscribed`, `expiry_date`)
		VALUES ('$national_id', '$fullname', '$passport_number', '$phone_number', '$reference', '$professionalism', '$email', '$city', '$province', '$country', '$driving_license', '$license_category', '$licence_file', '$user','$pass', '0', '0', '$date_')";
	if ($conn->query($sql)) {
	return "you have successfully registered  procced";
	} 
	else {
	return "Registering can no be done at this moment please try again later";;
	}
	//mysqli_close($conn);
}


function save_garages(){
$dbname="shoppate_database";
$username="shoppate_datause";
$password="shoppate_database";
$host="localhost";
$conn= new mysqli($host,$username,$password,$dbname); 
$national_id=$_POST['national_id'];
$passport_number=$_POST['passport_number'];
$email=$_POST['email'];
$province=$_POST['province'];
$city=$_POST['city'];
$country=$_POST['country'];
$location=$_POST['location'];
$date_=date("Y-m-d");

		$sql = "INSERT INTO `app_drivers` (`national_id`, `passport_number`, `email_address`, `city`, `province`, `country`, `location_map`, `user_id`, `is_subscribed`, `is_active`, `expiry_date`, `date_added`) VALUES ('$national_id', '$passport_number', '$email', '$city', '$province', '$country', '$location', '$user_id', '0', '0', '0', '$date_')";
	if ($conn->query($sql)) {
			return "you have successfully registered  procced";
	} 
	else {
		return "Registering can no be done at this moment please try again later";
	}
	//mysqli_close($conn);
}
function send_message ($number,$msg){
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.mista.io/sms',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => array('to' => "$number",'from' => 'St. Jacob','unicode' => '0','sms' => "$msg",'action' => 'send-sms'),
  CURLOPT_HTTPHEADER => array(
    'x-api-key: bsr2UzOFg15KiKPGa95JifogLzShkHrXz3R6BrVW'
  ),
));

 $response = curl_exec($curl);

curl_close($curl);

  return $response ;
}
$msg="test";
$number="250787967023";//"250788637555";
//$status=send_messages($number,$msg);
?>